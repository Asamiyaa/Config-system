# -*- coding: utf-8 -*-
"""A股ETF板块轮动自动跟踪器

模式：
  python daily_update.py                 # 盘后全量更新、评分、建议、历史记录
  python daily_update.py --intraday      # 仅更新ETF盘中行情快照，不改收盘评分

需要：Windows + Microsoft Excel 桌面版 + Python 3.11+ + akshare + pywin32
数据来源：AKShare聚合的公开行情/新闻接口（底层站点可能限流或调整）。
"""
from __future__ import annotations

import argparse
import math
import os
import re
import sys
import time
import traceback
from datetime import datetime, timedelta
from statistics import pstdev
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

try:
    import akshare as ak
except Exception as exc:  # pragma: no cover
    print("无法导入 akshare，请先运行 install.bat。错误：", exc)
    raise

try:
    import win32com.client as win32
except Exception as exc:  # pragma: no cover
    print("无法导入 pywin32。请确认在 Windows 上安装了 pywin32，并安装 Microsoft Excel。错误：", exc)
    raise

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WORKBOOK = os.path.join(BASE_DIR, "A股板块轮动_ETF自动跟踪.xlsx")
XL_UP = -4162
XL_CALCULATION_AUTOMATIC = -4105


class Tee:
    """Write console output and a dated log file at the same time."""
    def __init__(self, *streams):
        self.streams = streams

    def write(self, text):
        for stream in self.streams:
            try:
                stream.write(text)
                stream.flush()
            except Exception:
                pass
        return len(text)

    def flush(self):
        for stream in self.streams:
            try:
                stream.flush()
            except Exception:
                pass

    def isatty(self):
        return any(getattr(stream, "isatty", lambda: False)() for stream in self.streams)


def enable_file_log():
    log_dir = os.path.join(BASE_DIR, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, datetime.now().strftime("%Y%m%d") + ".log")
    handle = open(log_path, "a", encoding="utf-8", buffering=1)
    sys.stdout = Tee(sys.__stdout__, handle)
    sys.stderr = Tee(sys.__stderr__, handle)
    print(f"\n===== A股ETF跟踪运行开始 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")

POSITIVE_WORDS = [
    "支持", "出台", "落地", "推进", "增长", "预增", "扭亏", "订单", "中标", "扩产", "提价", "涨价",
    "需求增长", "盈利改善", "超预期", "突破", "创新", "资本开支", "投资增加", "景气回升", "采购", "补贴",
    "专项债", "国产替代", "放量", "商业化", "批量交付", "业绩增长", "上调", "回暖", "复苏", "降息", "降准"
]
NEGATIVE_WORDS = [
    "处罚", "立案", "调查", "减持", "下滑", "下降", "亏损", "收缩", "禁令", "限制", "制裁", "问询",
    "风险提示", "严重异常波动", "重点监控", "不及预期", "业绩下修", "产能过剩", "库存积压", "降价",
    "需求疲软", "订单减少", "暂停", "终止", "暴跌", "跌停", "退潮", "监管措施", "被否", "延期"
]
EARNINGS_WORDS = ["业绩", "盈利", "收入", "利润", "订单", "中标", "交付", "毛利率", "库存", "产能利用率", "批量", "预增", "扭亏", "现金流", "指引"]

# Only used to annotate theme mapping of raw LHB rows; the score remains a low-weight confirmation factor.
THEME_ALIAS = {
    "宽基-大盘": ["沪深300", "大盘", "权重", "蓝筹"],
    "宽基-中盘": ["中证500", "中盘", "制造"],
    "成长-创业板": ["创业板", "成长", "新能源", "医药"],
    "成长-科创50": ["科创", "半导体", "芯片", "硬科技"],
    "金融-证券": ["证券", "券商", "金融", "成交额"],
    "防御-红利": ["红利", "高股息", "股息", "国企", "央企"],
    "科技-半导体": ["半导体", "芯片", "晶圆", "设备", "材料"],
    "科技-芯片": ["芯片", "存储", "集成电路", "封测"],
    "科技-人工智能": ["人工智能", "AI", "算力", "大模型", "服务器", "光模块"],
    "科技-通信": ["通信", "5G", "光通信", "光模块", "光纤", "PCB"],
    "军工": ["军工", "国防", "航空", "航天", "装备"],
    "新能源车": ["新能源车", "汽车", "锂电", "智能驾驶", "整车"],
    "光伏": ["光伏", "硅料", "硅片", "组件", "逆变器"],
    "有色金属": ["有色", "铜", "铝", "黄金", "金属", "矿山"],
    "稀土资源": ["稀土", "稀有金属", "关键矿产", "资源"],
    "机器人": ["机器人", "人形", "减速器", "自动化", "电机"],
    "电池": ["电池", "储能", "固态电池", "正极", "负极"],
    "医药": ["医药", "创新药", "药品", "临床", "医保"],
    "医疗": ["医疗", "器械", "医院", "集采", "医疗设备"],
    "消费": ["消费", "内需", "零售", "家电", "食品"],
    "白酒": ["白酒", "酒类", "批价", "经销商"],
    "银行": ["银行", "信贷", "社融", "净息差", "不良率"],
    "基建": ["基建", "专项债", "财政", "工程机械", "水利"]
}


def safe_float(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None or (isinstance(value, float) and math.isnan(value)):
            return default
        if isinstance(value, str):
            value = value.replace(",", "").replace("%", "").strip()
            if value in ("", "--", "-", "None", "nan", "NaN"):
                return default
        x = float(value)
        return x if math.isfinite(x) else default
    except (TypeError, ValueError):
        return default


def clip(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def get_any(row: Dict[str, Any], candidates: List[str], default: Any = None) -> Any:
    for c in candidates:
        if c in row and pd.notna(row[c]):
            return row[c]
    # fuzzy match by substring to tolerate upstream column changes
    lowmap = {str(k).lower(): k for k in row.keys()}
    for cand in candidates:
        cc = cand.lower()
        for low, original in lowmap.items():
            if cc in low and pd.notna(row[original]):
                return row[original]
    return default


def call_api(api_name: str, *args, **kwargs):
    fn = getattr(ak, api_name, None)
    if fn is None:
        raise AttributeError(f"AKShare当前版本没有接口 {api_name}")
    return fn(*args, **kwargs)


def read_excel_config(excel_wb) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    ws = excel_wb.Worksheets("参数设置")
    config = {
        "portfolio_value": safe_float(ws.Range("B5").Value, 100000.0) or 100000.0,
        "max_equity": safe_float(ws.Range("B6").Value, 0.65) or 0.65,
        "max_single": safe_float(ws.Range("B7").Value, 0.12) or 0.12,
        "tech_cap": safe_float(ws.Range("B8").Value, 0.30) or 0.30,
        "cyclical_cap": safe_float(ws.Range("B9").Value, 0.25) or 0.25,
        "defensive_cap": safe_float(ws.Range("B10").Value, 0.30) or 0.30,
        "risk_budget": safe_float(ws.Range("B11").Value, 0.005) or 0.005,
        "drawdown_alarm": safe_float(ws.Range("B12").Value, 0.12) or 0.12,
        "leverage_switch": int(safe_float(ws.Range("B13").Value, 0) or 0),
        "min_score": safe_float(ws.Range("B14").Value, 65) or 65,
        "strong_score": safe_float(ws.Range("B15").Value, 80) or 80,
        "benchmark": str(ws.Range("B16").Value or "510300").strip().zfill(6),
    }
    vals = ws.Range("A20:G60").Value
    etfs = []
    if vals:
        for r in vals:
            if not r:
                continue
            code = str(r[0] or "").strip()
            if not code or code.lower() in ("none", "nan"):
                continue
            enabled = int(safe_float(r[6], 1) or 0) if len(r) > 6 else 1
            if enabled != 1:
                continue
            etfs.append({
                "code": code.zfill(6),
                "theme": str(r[1] or "未知板块").strip(),
                "logic": str(r[2] or "").strip(),
                "keywords": [x.strip() for x in str(r[3] or "").split("|") if x.strip()],
                "risk_group": str(r[4] or "其他").strip(),
                "source_note": str(r[5] or "AKShare/东方财富").strip(),
            })
    return config, etfs


def normalize_hist(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    out = df.copy()
    rename = {}
    for col in out.columns:
        s = str(col)
        if s in ("日期", "交易日期", "date", "时间"):
            rename[col] = "date"
        elif s in ("开盘", "开盘价", "open"):
            rename[col] = "open"
        elif s in ("收盘", "收盘价", "最新价", "close"):
            rename[col] = "close"
        elif s in ("最高", "最高价", "high"):
            rename[col] = "high"
        elif s in ("最低", "最低价", "low"):
            rename[col] = "low"
        elif s in ("成交量", "volume"):
            rename[col] = "volume"
        elif s in ("成交额", "amount", "成交金额"):
            rename[col] = "amount"
        elif s in ("涨跌幅", "涨跌幅%", "pct_chg"):
            rename[col] = "pct"
    out = out.rename(columns=rename)
    if "date" not in out.columns or "close" not in out.columns:
        return pd.DataFrame()
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    for c in ["open", "close", "high", "low", "volume", "amount", "pct"]:
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce")
    out = out.dropna(subset=["date", "close"]).sort_values("date").drop_duplicates("date", keep="last")
    return out.reset_index(drop=True)


def fetch_etf_hist(code: str, start: str, end: str) -> pd.DataFrame:
    last_exc = None
    for attempt in range(2):
        try:
            raw = call_api("fund_etf_hist_em", symbol=code, period="daily", start_date=start, end_date=end, adjust="qfq")
            df = normalize_hist(raw)
            if not df.empty:
                return df
            last_exc = RuntimeError("历史行情接口返回空表")
        except Exception as exc:
            last_exc = exc
        time.sleep(0.7 * (attempt + 1))
    raise RuntimeError(f"ETF {code}历史行情获取失败：{last_exc}")


def fetch_news() -> Tuple[List[Dict[str, Any]], Dict[str, str]]:
    rows: List[Dict[str, Any]] = []
    errors: Dict[str, str] = {}
    # Try several upstreams; not all endpoints are available in every AKShare version.
    for api_name in ["stock_info_global_cls", "stock_info_global_em", "stock_info_global_sina", "stock_info_global_ths"]:
        try:
            raw = call_api(api_name)
            if raw is None or getattr(raw, "empty", True):
                errors[api_name] = "返回空表"
                continue
            for item in raw.head(150).to_dict("records"):
                title = str(get_any(item, ["标题", "新闻标题", "内容", "title", "新闻内容", "摘要", "快讯内容"], "") or "").strip()
                if not title:
                    title = " | ".join(f"{k}:{v}" for k, v in item.items() if v is not None)[:500]
                time_v = get_any(item, ["发布时间", "时间", "日期", "发布时刻", "datetime", "time"], "")
                source = str(get_any(item, ["来源", "文章来源", "媒体", "source"], api_name) or api_name)
                url = str(get_any(item, ["链接", "新闻链接", "url", "详情链接", "网址"], "") or "")
                if title:
                    rows.append({"time": str(time_v), "source": source, "title": title[:1000], "url": url, "api": api_name})
            if len(rows) >= 30:
                break
        except Exception as exc:
            errors[api_name] = str(exc)[:200]
        time.sleep(0.2)
    # De-duplicate by headline text.
    unique = {}
    for r in rows:
        key = re.sub(r"\s+", "", r["title"])[:160]
        if key and key not in unique:
            unique[key] = r
    return list(unique.values())[:250], errors


def fetch_breadth() -> Tuple[Optional[int], Optional[int], Optional[float], str]:
    try:
        df = call_api("stock_zh_a_spot_em")
        if df is None or df.empty:
            return None, None, None, "A股现货接口返回空表"
        pct_col = next((c for c in df.columns if str(c) in ("涨跌幅", "涨跌幅%")), None)
        name_col = next((c for c in df.columns if str(c) in ("名称", "股票简称")), None)
        if pct_col is None:
            return None, None, None, "A股现货接口缺少涨跌幅列"
        x = df.copy()
        x[pct_col] = pd.to_numeric(x[pct_col], errors="coerce")
        if name_col:
            names = x[name_col].astype(str)
            x = x[~names.str.contains(r"(^\*?ST|退市|退$)", regex=True, na=False)]
        changes = x[pct_col].dropna()
        up = int((changes > 0).sum())
        down = int((changes < 0).sum())
        total = up + down
        ratio = up / total if total else None
        return up, down, ratio, "OK"
    except Exception as exc:
        return None, None, None, f"A股宽度获取失败：{exc}"


def fetch_pool(api_name: str, date_str: str) -> Tuple[pd.DataFrame, str]:
    try:
        df = call_api(api_name, date=date_str)
        if df is None:
            return pd.DataFrame(), f"{api_name}: None"
        return df, "OK" if not df.empty else f"{api_name}: 当日为空"
    except Exception as exc:
        return pd.DataFrame(), f"{api_name}: {exc}"


def fetch_lhb(date_str: str) -> Tuple[pd.DataFrame, str]:
    # API signature has changed across AKShare versions; try current common signature and Sina fallback.
    attempts = [
        ("stock_lhb_detail_em", {"start_date": date_str, "end_date": date_str}),
        ("stock_lhb_detail_daily_sina", {}),
    ]
    last_err = "未尝试"
    for api_name, kwargs in attempts:
        try:
            raw = call_api(api_name, **kwargs)
            if raw is not None and not raw.empty:
                return raw, f"OK ({api_name})"
            last_err = f"{api_name}返回空表"
        except Exception as exc:
            last_err = f"{api_name}: {exc}"
    return pd.DataFrame(), f"龙虎榜数据缺失：{last_err}"


def series_metrics(df: pd.DataFrame, benchmark_ret20: Optional[float]) -> Dict[str, Any]:
    if df.empty or len(df) < 2:
        raise RuntimeError("历史数据不足")
    close = df["close"].astype(float)
    last = float(close.iloc[-1])
    prev = float(close.iloc[-2])
    ret = close.pct_change().dropna()
    ret1 = (last / prev - 1) * 100 if prev else 0.0
    ret5 = (last / float(close.iloc[-6]) - 1) * 100 if len(close) >= 6 else None
    ret20 = (last / float(close.iloc[-21]) - 1) * 100 if len(close) >= 21 else None
    ret60 = (last / float(close.iloc[-61]) - 1) * 100 if len(close) >= 61 else None
    ma20 = float(close.tail(20).mean()) if len(close) >= 20 else float(close.mean())
    ma60 = float(close.tail(60).mean()) if len(close) >= 60 else float(close.mean())
    vol_ann = float(ret.tail(20).std(ddof=0) * math.sqrt(252) * 100) if len(ret) >= 5 else None
    high60 = float(close.tail(60).max())
    dd60 = (last / high60 - 1) * 100 if high60 else None
    amount = float(df["amount"].iloc[-1]) if "amount" in df.columns and pd.notna(df["amount"].iloc[-1]) else None
    amounts = df["amount"].dropna().astype(float) if "amount" in df.columns else pd.Series(dtype=float)
    amount_ratio = None
    if len(amounts) >= 5 and amounts.tail(20).mean() > 0:
        amount_ratio = float(amounts.tail(5).mean() / amounts.tail(min(20, len(amounts))).mean())
    rel20 = ret20 - benchmark_ret20 if ret20 is not None and benchmark_ret20 is not None else None
    day = df["date"].iloc[-1].strftime("%Y-%m-%d")
    return {
        "trade_date": day, "close": last, "day_change": ret1, "ret5": ret5, "ret20": ret20,
        "ret60": ret60, "ma20": ma20, "ma60": ma60, "amount": amount,
        "amount_ratio": amount_ratio, "vol_ann": vol_ann, "dd60": dd60, "rel20": rel20,
        "raw_df": df,
    }


def classify_lifecycle(m: Dict[str, Any]) -> Tuple[str, float]:
    close, ma20, ma60 = m["close"], m["ma20"], m["ma60"]
    r5, r20, dd = m.get("ret5") or 0.0, m.get("ret20") or 0.0, m.get("dd60") or 0.0
    rel = m.get("rel20") or 0.0
    if close > ma20 > ma60 and r20 > 7 and r5 > 10:
        return "L4高位扩散/加速", 10.0
    if close > ma20 > ma60 and r20 > 0 and rel > 0:
        return "L3趋势主升", 14.0 if r20 > 5 else 12.0
    if close > ma20 and r20 > 0 and rel >= 0:
        return "L2趋势启动", 11.0
    if close > ma60 and (close <= ma20 or r20 <= 0):
        return "L1蓄势/回踩", 8.0
    if dd <= -18 and r5 > 0 and close >= ma20:
        return "L6二次筑底候选", 7.0
    if close < ma60 and r20 < 0 and dd < -10:
        return "L5退潮/弱势", 3.0
    if close < ma60 and r20 < 0:
        return "L0底部观察/未确认", 5.0
    return "L1震荡观察", 7.0


def technical_score(m: Dict[str, Any]) -> float:
    c, ma20, ma60 = m["close"], m["ma20"], m["ma60"]
    score = 0.0
    score += 4 if c > ma20 else 0
    score += 4 if c > ma60 else 0
    score += 3 if ma20 > ma60 else 0
    score += 2 if (m.get("rel20") is not None and m["rel20"] > 0) else 0
    if (m.get("day_change") or 0) > 0 and (m.get("amount_ratio") or 0) > 1.1:
        score += 2
    elif (m.get("day_change") or 0) > 0:
        score += 1
    return clip(score, 0, 15)


def sentiment_score(up_ratio: Optional[float], limitups: int, limitdowns: int, broken: int, max_streak: int, valid: bool=True) -> float:
    if not valid:
        return 5.0
    score = 5.0
    if up_ratio is not None:
        if up_ratio >= 0.65: score += 2
        elif up_ratio >= 0.55: score += 1
        elif up_ratio < 0.35: score -= 2
        elif up_ratio < 0.42: score -= 1
    if limitups >= 80: score += 1.5
    elif limitups >= 50: score += 1
    elif limitups < 20: score -= 1
    if max_streak >= 5: score += 1
    elif max_streak >= 3: score += 0.5
    elif max_streak <= 1: score -= 0.5
    if limitups + broken > 0:
        br = broken / (limitups + broken)
        if br > 0.45: score -= 2
        elif br > 0.35: score -= 1
        elif br < 0.20: score += 0.5
    if limitdowns >= 20: score -= 2
    elif limitdowns >= 10: score -= 1
    return round(clip(score, 0, 10), 1)


def board_col_match(df: pd.DataFrame, target_names: List[str]) -> Optional[str]:
    for c in df.columns:
        if any(x in str(c) for x in target_names):
            return str(c)
    return None


def pool_streak_max(df: pd.DataFrame) -> int:
    if df is None or df.empty:
        return 0
    col = board_col_match(df, ["连板数", "连续涨停", "连板"])
    if not col:
        return 0
    vals = []
    for x in df[col].tolist():
        if isinstance(x, str):
            m = re.search(r"\d+", x)
            if m: vals.append(int(m.group()))
        else:
            v = safe_float(x)
            if v is not None: vals.append(int(v))
    return max(vals) if vals else 0


def contains_keyword(text: str, keyword: str) -> bool:
    if keyword.strip().upper() == "AI":
        return bool(re.search(r"\bAI\b|人工智能|大模型", text, flags=re.IGNORECASE))
    return keyword.lower() in text.lower()


def match_news(theme_keywords: List[str], news_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    keywords = [k for k in theme_keywords if k]
    for n in news_rows:
        text = (n.get("title", "") + " " + n.get("source", ""))
        if any(contains_keyword(text, k) for k in keywords):
            out.append(n)
    return out[:60]


def news_scores(theme_keywords: List[str], news_rows: List[Dict[str, Any]], news_available: bool) -> Tuple[float, float, List[Dict[str, Any]], str]:
    if not news_available:
        return 7.5, 5.0, [], "新闻接口不可用：相关分项使用中性/基准值，可信度低"
    relevant = match_news(theme_keywords, news_rows)
    if not relevant:
        return 7.5, 5.0, [], "资讯源可用但无直接主题匹配：中性基准，不代表没有政策变化"
    policy = 7.5
    earnings = 5.0
    for n in relevant[:40]:
        text = n.get("title", "")
        pos = sum(1 for w in POSITIVE_WORDS if w in text)
        neg = sum(1 for w in NEGATIVE_WORDS if w in text)
        earn = sum(1 for w in EARNINGS_WORDS if w in text)
        freshness = 0.6
        try:
            dt = pd.to_datetime(n.get("time", ""), errors="coerce")
            if pd.notna(dt):
                days = max(0, (pd.Timestamp.now().normalize() - dt.normalize()).days)
                freshness = 1.0 if days <= 1 else 0.75 if days <= 3 else 0.4 if days <= 7 else 0.15
        except Exception:
            pass
        policy += freshness * (0.65 * min(pos, 2) - 0.85 * min(neg, 2))
        earnings += freshness * (0.25 * min(earn, 3) + 0.4 * min(pos, 2) - 0.55 * min(neg, 2))
    return round(clip(policy, 0, 15), 1), round(clip(earnings, 0, 10), 1), relevant, f"主题匹配新闻 {len(relevant)} 条，关键词打分"


def normalize_lhb(df: pd.DataFrame, trade_date: str, etfs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = []
    if df is None or df.empty:
        return rows
    for item in df.to_dict("records"):
        code = str(get_any(item, ["代码", "股票代码", "证券代码"], "") or "").zfill(6)
        name = str(get_any(item, ["名称", "股票简称", "证券简称"], "") or "")
        reason = str(get_any(item, ["上榜原因", "上榜原因类型", "解读", "异动类型", "涨跌幅原因", "原因"], "") or "")
        buy = safe_float(get_any(item, ["龙虎榜买入额", "买入额", "买入金额", "买入总额", "买方金额"]))
        sell = safe_float(get_any(item, ["龙虎榜卖出额", "卖出额", "卖出金额", "卖出总额", "卖方金额"]))
        net = safe_float(get_any(item, ["龙虎榜净买额", "净买额", "买卖净额", "净额"]))
        date_val = str(get_any(item, ["上榜日", "交易日", "日期", "日期时间"], trade_date) or trade_date)
        # A readable summary of seat/amount fields available in the upstream record.
        seat_parts = []
        for k, v in item.items():
            kl = str(k)
            if any(x in kl for x in ["机构", "营业部", "买入前", "卖出前", "席位"]):
                if pd.notna(v) and str(v).strip():
                    seat_parts.append(f"{kl}:{v}")
            if len(seat_parts) >= 5:
                break
        text = f"{name} {reason} " + " ".join(seat_parts)
        related_theme = ""
        related_code = ""
        for e in etfs:
            theme_words = THEME_ALIAS.get(e["theme"], [])
            if any(w.lower() in text.lower() for w in theme_words) or any(w.lower() in reason.lower() for w in e["keywords"]):
                related_theme = e["theme"]
                related_code = e["code"]
                break
        source = "AKShare龙虎榜接口（公开数据）"
        rows.append({"date": date_val, "code": code, "name": name, "reason": reason, "buy": buy, "sell": sell,
                     "net": net, "seats": "；".join(seat_parts)[:500], "theme": related_theme, "etf": related_code,
                     "risk": "核验上榜原因和次日反馈；不把席位净买额当作板块净流入", "source": source, "raw": item})
    return rows


def lhb_score(theme: str, keywords: List[str], lhb_rows: List[Dict[str, Any]], source_ok: bool) -> Tuple[float, str]:
    if not source_ok:
        return 2.5, "龙虎榜接口不可用，给中性分并标注缺失"
    hits = 0
    net_sum = 0.0
    for r in lhb_rows:
        txt = " ".join(str(r.get(k, "")) for k in ["name", "reason", "theme", "seats"])
        if any(k.lower() in txt.lower() for k in keywords if len(k) >= 2):
            hits += 1
            net_sum += safe_float(r.get("net"), 0.0) or 0.0
    if hits >= 5: score = 4.5 if net_sum >= 0 else 3.0
    elif hits >= 2: score = 3.5 if net_sum >= 0 else 2.5
    elif hits == 1: score = 3.0 if net_sum >= 0 else 2.0
    else: score = 2.5
    return score, f"相关龙虎榜行数={hits}；仅辅助验证"


def compute_macro_score(breadth: Optional[float], emotion: float, benchmark: Optional[Dict[str, Any]], growth: Optional[Dict[str, Any]]) -> Tuple[float, float, str]:
    total = 0.0
    reasons = []
    def trend_points(m: Optional[Dict[str, Any]], max_points: float) -> float:
        if not m:
            return max_points * 0.5
        pts = 0.0
        pts += max_points * 0.33 if m["close"] > m["ma20"] else 0
        pts += max_points * 0.33 if m["close"] > m["ma60"] else 0
        pts += max_points * 0.34 if m["ma20"] > m["ma60"] else 0
        return pts
    b_pts = trend_points(benchmark, 30)
    g_pts = trend_points(growth, 20)
    total += b_pts + g_pts
    if breadth is None:
        breadth_pts = 10
        reasons.append("市场宽度缺失")
    elif breadth >= 0.65: breadth_pts = 20
    elif breadth >= 0.55: breadth_pts = 15
    elif breadth >= 0.45: breadth_pts = 10
    elif breadth >= 0.35: breadth_pts = 5
    else: breadth_pts = 0
    total += breadth_pts
    total += emotion * 2
    if benchmark and benchmark.get("ret20") is not None:
        r = benchmark["ret20"]
        total += 10 if r >= 5 else 7 if r > 0 else 3 if r > -5 else 0
    else:
        total += 5
        reasons.append("沪深300 20日收益缺失")
    market_score = clip(total, 0, 100)
    macro = round(market_score * 0.15, 1)
    if not reasons:
        reasons.append(f"沪深300趋势={b_pts:.0f}/30，科创50趋势={g_pts:.0f}/20，涨跌宽度={breadth_pts}/20，情绪={emotion}/10")
    return macro, market_score, "；".join(reasons)


def market_state(score: float) -> str:
    if score >= 75: return "进攻趋势"
    if score >= 60: return "震荡偏强"
    if score >= 45: return "震荡轮动"
    if score >= 30: return "防御模式"
    return "高风险/降仓"


def exposure_cap(market_score: float, max_equity: float) -> float:
    if market_score < 25: cap = 0.15
    elif market_score < 40: cap = 0.25
    elif market_score < 50: cap = 0.35
    elif market_score < 60: cap = 0.45
    elif market_score < 70: cap = 0.55
    else: cap = 0.65
    return min(cap, max_equity)


def score_etf(e: Dict[str, Any], m: Dict[str, Any], macro: float, emotion: float, news_rows: List[Dict[str, Any]], news_available: bool,
              lhb_rows: List[Dict[str, Any]], lhb_available: bool, market_score: float, config: Dict[str, Any]) -> Dict[str, Any]:
    lifecycle, cyc_score = classify_lifecycle(m)
    tech = technical_score(m)
    policy, earnings, relevant_news, news_reason = news_scores(e["keywords"], news_rows, news_available)
    flow_ratio = m.get("amount_ratio")
    flow = 5.0
    if flow_ratio is not None:
        flow += 4 if flow_ratio >= 1.5 else 3 if flow_ratio >= 1.2 else 2 if flow_ratio >= 0.9 else 0.5
    flow += 3 if (m.get("ret20") or 0) > 0 else 0
    flow += 2 if (m.get("ret5") or 0) > 0 else 0
    flow += 1 if (m.get("day_change") or 0) > 0 else 0
    flow = round(clip(flow, 0, 15), 1)
    lhb, lhb_reason = lhb_score(e["theme"], e["keywords"], lhb_rows, lhb_available)
    risk_penalty = 0.0
    if m["close"] < m["ma60"] and (m.get("ret20") or 0) < 0: risk_penalty += 4
    if (m.get("dd60") or 0) <= -12: risk_penalty += 3
    if market_score < 30: risk_penalty += 3
    if (m.get("amount_ratio") or 0) > 2.0 and (m.get("ret5") or 0) > 10: risk_penalty += 2
    if lifecycle.startswith("L4"): risk_penalty += 2
    risk_penalty = min(risk_penalty, 15)
    component_sum = macro + policy + cyc_score + tech + flow + emotion + lhb + earnings
    total = clip(component_sum - risk_penalty, 0, 100)
    has_data = True
    if market_score < 30:
        state = "风险门槛：暂停新增风险仓"
    elif total >= config["strong_score"] and tech >= 10 and m["close"] > m["ma20"] > m["ma60"] and not lifecycle.startswith("L4"):
        state = "高优先级候选"
    elif total >= config["min_score"] and m["close"] > m["ma60"] and tech >= 8:
        state = "候选观察/等确认"
    elif total >= 55:
        state = "观察：等待结构改善"
    elif lifecycle.startswith("L5"):
        state = "弱势/退潮"
    else:
        state = "低优先级/不新开"
    if lifecycle.startswith("L5") or (m["close"] < m["ma60"] and (m.get("ret20") or 0) < 0):
        action = "弱势/破位：不抄底；已有仓位按退出规则降风险"
    elif market_score < 30:
        action = "防御模式：不新增主题仓；优先检查回撤与相关性"
    elif state == "高优先级候选":
        action = "趋势候选：分批；只在突破确认/缩量回踩承接后加仓，勿追急涨"
    elif state == "候选观察/等确认":
        action = "候选：等待突破或回踩确认；轻仓试错，设置失效位"
    elif lifecycle.startswith("L4"):
        action = "高位扩散：停止追涨，优先管理已有仓位与止盈"
    else:
        action = "继续观察：等待相对强度、均线或成交额改善"
    news_titles = "；".join([n.get("title", "")[:55] for n in relevant_news[:2]])
    evidence = f"{news_reason}；{lhb_reason}；相对沪深30020日={m.get('rel20') if m.get('rel20') is not None else '缺失'}%"[:1200]
    if news_titles:
        evidence += "；新闻=" + news_titles
    quality_parts = ["ETF日线OK"]
    if not news_available: quality_parts.append("新闻缺失")
    if not lhb_available: quality_parts.append("龙虎榜缺失")
    if m.get("ret60") is None: quality_parts.append("60日收益样本不足")
    return {
        **e, **m, "macro": round(macro,1), "policy": policy, "cycle_score": cyc_score, "tech": tech,
        "flow": flow, "emotion": emotion, "lhb_score": lhb, "earnings": earnings, "risk_penalty": risk_penalty,
        "score": round(total,1), "lifecycle": lifecycle, "state": state, "action": action,
        "evidence": evidence, "quality": "；".join(quality_parts), "relevant_news": relevant_news,
    }


def allocate_weights(rows: List[Dict[str, Any]], config: Dict[str, Any], market_score: float) -> float:
    cap = exposure_cap(market_score, config["max_equity"])
    group_caps = {
        "成长科技": config["tech_cap"],
        "周期资源": config["cyclical_cap"],
        "防御红利": config["defensive_cap"],
        "金融周期": config["defensive_cap"],
        "宽基": cap,
        "其他": config["max_single"],
    }
    for r in rows:
        r["target_weight"] = 0.0
        eligible = (r["score"] >= config["min_score"] and r["tech"] >= 8 and r["close"] > r["ma60"] and market_score >= 30 and r["risk_penalty"] < 8 and not r["lifecycle"].startswith("L4"))
        if eligible:
            r["target_weight"] = min(config["max_single"], max(0.0, (r["score"] - 55) / 25 * config["max_single"]))
    used_by_group: Dict[str, float] = {}
    total = 0.0
    for r in sorted(rows, key=lambda x: x["score"], reverse=True):
        group = r["risk_group"]
        limit = group_caps.get(group, config["max_single"])
        remaining_group = max(0.0, limit - used_by_group.get(group, 0.0))
        w = min(r["target_weight"], remaining_group)
        r["target_weight"] = w
        used_by_group[group] = used_by_group.get(group, 0.0) + w
        total += w
    if total > cap and total > 0:
        scale = cap / total
        for r in rows:
            r["target_weight"] *= scale
        total = cap
    for r in rows:
        r["target_weight"] = round(r["target_weight"], 4)
    return round(total, 4)


def com_write_matrix(ws, start: str, rows: List[List[Any]]):
    if not rows:
        return
    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise ValueError(f"矩阵列数不一致: expected {width}, got {len(row)}")
    ws.Range(start).Resize(len(rows), width).Value = tuple(tuple(v for v in row) for row in rows)


def clear_body(ws, start_row: int, end_col: str, start_col: str="A", end_row: int=10000):
    ws.Range(f"{start_col}{start_row}:{end_col}{end_row}").ClearContents()


def format_date_str(value: Any) -> str:
    if value is None:
        return ""
    try:
        return pd.to_datetime(value, errors="coerce").strftime("%Y-%m-%d")
    except Exception:
        return str(value)[:30]


def run_intraday(excel_wb, config: Dict[str, Any], etfs: List[Dict[str, Any]]) -> None:
    print("开始拉取盘中ETF行情快照……")
    raw = call_api("fund_etf_spot_em")
    if raw is None or raw.empty:
        raise RuntimeError("ETF实时行情接口返回空表")
    recs = raw.to_dict("records")
    by_code = {}
    for r in recs:
        code = str(get_any(r, ["代码", "基金代码", "证券代码"], "") or "").zfill(6)
        if code and code != "000000":
            by_code[code] = r
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    out = []
    for e in etfs:
        r = by_code.get(e["code"])
        if not r:
            out.append([now, e["code"], e["theme"], None, None, None, "实时源未匹配；保留空值"])
            continue
        last = safe_float(get_any(r, ["最新价", "最新", "现价", "单位净值"]))
        pct = safe_float(get_any(r, ["涨跌幅", "涨跌幅%", "日涨幅"]))
        amount = safe_float(get_any(r, ["成交额", "成交金额"]))
        out.append([now, e["code"], e["theme"], last, pct, amount, "AKShare fund_etf_spot_em；报价可能延迟"])
    ws = excel_wb.Worksheets("盘中行情")
    clear_body(ws, 5, "G", "A", max(5000, len(out)+5))
    com_write_matrix(ws, "A5", out)
    dash = excel_wb.Worksheets("总览")
    dash.Range("B2").Value = now
    dash.Range("H2").Value = "盘中快照完成；收盘评分未更新"
    print(f"盘中快照写入 {len(out)} 只ETF。")


def update_workbook(excel_wb, config: Dict[str, Any], etfs: List[Dict[str, Any]], metrics: List[Dict[str, Any]],
                    market_info: Dict[str, Any], ladder_rows: List[List[Any]], lhb_rows: List[Dict[str, Any]],
                    news_rows: List[Dict[str, Any]], history_rows: List[List[Any]], asof: str) -> None:
    ws_score = excel_wb.Worksheets("ETF评分")
    # Keep user-edited current weights (AD) by code, rather than assuming config ordering is unchanged.
    prev_last = ws_score.Cells(ws_score.Rows.Count, 2).End(XL_UP).Row
    current_weights: Dict[str, Any] = {}
    if prev_last >= 5:
        existing = ws_score.Range(f"B5:AD{prev_last}").Value
        if existing:
            for r in existing:
                if r and len(r) >= 29:
                    code = str(r[0] or "").zfill(6)
                    current_weights[code] = r[28]
    clear_body(ws_score, 5, "AI", "A", max(200, 4+len(etfs)+5))

    score_by_code = {m["code"]: m for m in metrics}
    # Write A:Y and AA:AD/AF:AI in blocks; keep calculated columns Z, AE, AJ:AL as formulas.
    for idx, e in enumerate(etfs):
        row_num = 5 + idx
        r = score_by_code.get(e["code"])
        ws_score.Range(f"Z{row_num}").Formula = f'=IF(E{row_num}="","",MAX(0,MIN(100,SUM(Q{row_num}:X{row_num})-Y{row_num})))'
        ws_score.Range(f"AE{row_num}").Formula = f'=IF(AC{row_num}="","",AC{row_num}-AD{row_num})'
        ws_score.Range(f"AJ{row_num}").Formula = f"""=IF(AC{row_num}="","",AC{row_num}*'参数设置'!$B$5)"""
        ws_score.Range(f"AK{row_num}").Formula = f"""=IF(AD{row_num}="","",AD{row_num}*'参数设置'!$B$5)"""
        ws_score.Range(f"AL{row_num}").Formula = f"""=IF(AJ{row_num}="","",AJ{row_num}-AK{row_num})"""
        current_w = current_weights.get(e["code"], 0.0)
        current_w = safe_float(current_w, 0.0) or 0.0
        if r is None:
            prefix = [asof, e["code"], e["theme"], e["logic"]] + [None]*12 + [None]*9
            suffix_aa_ad = ["数据缺失", "数据缺失/不打分", None, current_w]
            suffix_af_ai = ["数据不足：不生成仓位建议", "行情未取回；不要将缺失值解释为0分", "失败", "AKShare fund_etf_hist_em"]
            com_write_matrix(ws_score, f"A{row_num}", [prefix])
            com_write_matrix(ws_score, f"AA{row_num}", [suffix_aa_ad])
            com_write_matrix(ws_score, f"AF{row_num}", [suffix_af_ai])
            continue
        amount_yi = r.get("amount") / 1e8 if r.get("amount") is not None else None
        prefix = [
            asof, e["code"], e["theme"], e["logic"], r["close"], r.get("day_change"), r.get("ret5"), r.get("ret20"), r.get("ret60"),
            r.get("rel20"), r.get("ma20"), r.get("ma60"), amount_yi, r.get("amount_ratio"), r.get("vol_ann"), r.get("dd60"),
            r.get("macro"), r.get("policy"), r.get("cycle_score"), r.get("tech"), r.get("flow"), r.get("emotion"), r.get("lhb_score"),
            r.get("earnings"), r.get("risk_penalty")
        ]
        suffix_aa_ad = [r["lifecycle"], r["state"], r["target_weight"], current_w]
        suffix_af_ai = [r["action"], r["evidence"], r["quality"], "https://github.com/akfamily/akshare/blob/main/docs/data/fund/fund_public.md ; https://github.com/akfamily/akshare/blob/main/docs/tutorial.md"]
        com_write_matrix(ws_score, f"A{row_num}", [prefix])
        com_write_matrix(ws_score, f"AA{row_num}", [suffix_aa_ad])
        com_write_matrix(ws_score, f"AF{row_num}", [suffix_af_ai])

    # Market sentiment/detail sheet
    ws = excel_wb.Worksheets("市场情绪")
    data_vals = {
        "B5": market_info.get("trade_date"),
        "B6": market_info.get("up"), "B7": market_info.get("down"), "B8": market_info.get("breadth"),
        "B9": market_info.get("limitup"), "B10": market_info.get("limitdown"), "B11": market_info.get("broken"),
        "B12": market_info.get("broken_ratio"), "B13": market_info.get("max_streak"), "B14": market_info.get("benchmark_trend"),
        "B15": market_info.get("growth_trend"), "B16": market_info.get("emotion"), "B17": market_info.get("macro"),
        "B18": market_info.get("market_score"), "B19": market_info.get("equity_cap"), "B20": 1-market_info.get("equity_cap",0), "B21": market_info.get("data_status")
    }
    for cell, val in data_vals.items(): ws.Range(cell).Value = val
    # Give previous/compare values and status text
    status_vals = {
        "D6": "涨跌家数" if market_info.get("up") is not None else "数据缺失",
        "D7": "涨跌家数" if market_info.get("down") is not None else "数据缺失",
        "D8": "偏强" if (market_info.get("breadth") or 0) > .55 else "偏弱/中性",
        "D9": "情绪扩散" if (market_info.get("limitup") or 0) >= 50 else "扩散不足/中性",
        "D10": "风险升高" if (market_info.get("limitdown") or 0) >= 10 else "常规观察",
        "D11": "待比较",
        "D12": "风险高" if (market_info.get("broken_ratio") or 0) > .35 else "承接尚可/待复核",
        "D13": f"最高{market_info.get('max_streak') or 0}板",
        "D14": market_info.get("benchmark_trend"), "D15": market_info.get("growth_trend"),
        "D16": "情绪改善" if (market_info.get("emotion") or 0) >= 7 else "中性/谨慎" if (market_info.get("emotion") or 0) >= 4 else "情绪弱势",
        "D17": "较强" if (market_info.get("macro") or 0) >= 10 else "中性" if (market_info.get("macro") or 0) >= 7 else "偏弱",
        "D18": market_state(market_info.get("market_score", 50)),
        "D19": "按风险预算约束", "D20": "现金/低风险资产占比", "D21": "具体源状态见备注/脚本日志"
    }
    for cell, val in status_vals.items(): ws.Range(cell).Value = val
    ws.Range("C5").Value = "最近完整交易日"
    ws.Range("C6").Value = "不含ST/退市（若名称列可识别）"
    ws.Range("C8").Value = "百分比"
    ws.Range("C12").Value = "炸板/(涨停+炸板)"
    ws.Range("C19").Value = "参数设置最大值内"

    # Dashboard KPIs
    dash = excel_wb.Worksheets("总览")
    dash.Range("B2").Value = asof
    dash.Range("E2").Value = market_info.get("trade_date")
    dash.Range("H2").Value = market_info.get("data_status")
    dash.Range("B4").Value = market_info.get("market_score")
    dash.Range("E4").Value = market_state(market_info.get("market_score", 50))
    dash.Range("H4").Value = market_info.get("equity_cap")
    dash.Range("K4").Value = 1-market_info.get("equity_cap",0)
    dash.Range("G5").Value = "杠杆状态"
    dash.Range("H5").Value = "关闭（不自动加杠杆）" if not config["leverage_switch"] else "参数已开启，但脚本仍不自动下达杠杆指令"
    # Top 10 recommendation rows; current positions can be compared in ETF评分.
    top = sorted(metrics, key=lambda x: x["score"], reverse=True)[:10]
    dash_rows = []
    for rank, r in enumerate(top, 1):
        dash_rows.append([rank, r["code"], r["theme"], r["score"], r["state"], r["lifecycle"], r["target_weight"], r["close"], r.get("day_change"), r["action"], r["evidence"][:160]])
    clear_body(dash, 8, "K", "A", 17)
    if dash_rows:
        com_write_matrix(dash, "A8", dash_rows)
    # If fewer than 10 rows, rest remain blank after clear.
    dash.Range("G8:G17").NumberFormat = "0.0%"

    # Ladder sheet: standardized rows
    ws = excel_wb.Worksheets("涨停梯队")
    clear_body(ws, 5, "M", "A", 10000)
    if ladder_rows:
        com_write_matrix(ws, "A5", ladder_rows[:300])
    # LHB sheet
    ws = excel_wb.Worksheets("龙虎榜")
    clear_body(ws, 5, "L", "A", 10000)
    lhbm = []
    for r in lhb_rows[:500]:
        lhbm.append([r.get("date"), r.get("code"), r.get("name"), r.get("reason"), r.get("buy"), r.get("sell"), r.get("net"), r.get("seats"), r.get("theme"), r.get("etf"), r.get("risk"), r.get("source")])
    if lhbm: com_write_matrix(ws, "A5", lhbm)

    # News sheet
    ws = excel_wb.Worksheets("政策新闻")
    clear_body(ws, 5, "H", "A", 10000)
    newsm = []
    for n in news_rows[:500]:
        title = n.get("title", "")
        pos = "、".join([w for w in POSITIVE_WORDS if w in title][:8])
        neg = "、".join([w for w in NEGATIVE_WORDS if w in title][:8])
        sentiment = clip(5 + min(4, len(pos.split("、")) if pos else 0) - min(4, len(neg.split("、")) if neg else 0), 0, 10)
        themes = []
        low = title.lower()
        for e in etfs:
            if any(contains_keyword(title, k) for k in e["keywords"]): themes.append(e["theme"])
        newsm.append([n.get("time"), n.get("source"), title, "、".join(themes[:6]), pos, neg, sentiment, n.get("url") or n.get("api") or "AKShare资讯接口"])
    if newsm: com_write_matrix(ws, "A5", newsm)

    # Historical prices: store the latest 120 calendar days; enough for review but keeps workbook bounded.
    ws = excel_wb.Worksheets("历史行情")
    clear_body(ws, 5, "J", "A", 100000)
    if history_rows: com_write_matrix(ws, "A5", history_rows)

    # Historical score snapshots: update an existing same-date/code row instead of duplicating
    # the same trading date on a Chinese market holiday or on a second run after close.
    ws = excel_wb.Worksheets("历史跟踪")
    last_row = ws.Cells(ws.Rows.Count, 1).End(XL_UP).Row
    key_to_row: Dict[Tuple[str, str], int] = {}
    if last_row >= 5:
        existing_keys = ws.Range(f"B5:C{last_row}").Value
        for offset, keyrow in enumerate(existing_keys or []):
            if keyrow and keyrow[0] and keyrow[1]:
                key_to_row[(str(keyrow[0])[:10], str(keyrow[1]).zfill(6))] = 5 + offset
    next_row = max(5, last_row + 1)
    for r in metrics:
        track_row = [asof, r["trade_date"], r["code"], r["theme"], r["score"], r["lifecycle"], r["state"], r["target_weight"], r["close"], r["action"]]
        key = (str(r["trade_date"])[:10], str(r["code"]).zfill(6))
        if key in key_to_row:
            dest = key_to_row[key]
        else:
            dest = next_row
            key_to_row[key] = dest
            next_row += 1
        com_write_matrix(ws, f"A{dest}", [track_row])

    # Set formula calculation and save.
    excel_wb.Application.CalculateFullRebuild()
    excel_wb.Save()


def main() -> int:
    enable_file_log()
    parser = argparse.ArgumentParser(description="A股ETF板块轮动自动跟踪器")
    parser.add_argument("--intraday", action="store_true", help="仅刷新实时ETF行情快照，不重算日线评分")
    parser.add_argument("--premarket", action="store_true", help="仅刷新财经资讯/政策关键词表，不重算日线评分")
    args = parser.parse_args()
    if not os.path.exists(WORKBOOK):
        print(f"找不到Excel：{WORKBOOK}\n请先确认该脚本与 A股板块轮动_ETF自动跟踪.xlsx 在同一文件夹。")
        return 2

    excel = None
    book = None
    try:
        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.AskToUpdateLinks = False
        excel.Calculation = XL_CALCULATION_AUTOMATIC
        book = excel.Workbooks.Open(WORKBOOK, UpdateLinks=0, ReadOnly=False)
        config, etfs = read_excel_config(book)
        if not etfs:
            raise RuntimeError("参数设置中没有启用的ETF。请检查A20:G60的启用列。")
        asof = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if args.intraday:
            run_intraday(book, config, etfs)
            book.Save()
            return 0
        if args.premarket:
            print("开始盘前财经资讯更新（不更新日线评分与目标仓位）……")
            news_rows, news_errors = fetch_news()
            ws_news = book.Worksheets("政策新闻")
            clear_body(ws_news, 5, "H", "A", 10000)
            newsm = []
            for n in news_rows[:500]:
                title = n.get("title", "")
                pos = "、".join([w for w in POSITIVE_WORDS if w in title][:8])
                neg = "、".join([w for w in NEGATIVE_WORDS if w in title][:8])
                sentiment = clip(5 + min(4, len(pos.split("、")) if pos else 0) - min(4, len(neg.split("、")) if neg else 0), 0, 10)
                themes = []
                low = title.lower()
                for e in etfs:
                    if any(contains_keyword(title, k) for k in e["keywords"]): themes.append(e["theme"])
                newsm.append([n.get("time"), n.get("source"), title, "、".join(themes[:6]), pos, neg, sentiment, n.get("url") or n.get("api") or "AKShare资讯接口"])
            if newsm:
                com_write_matrix(ws_news, "A5", newsm)
            dash = book.Worksheets("总览")
            dash.Range("B2").Value = asof
            dash.Range("H2").Value = f"盘前新闻刷新：{len(newsm)} 条；日线评分未重算"
            book.Save()
            print(f"盘前资讯更新完成：{len(newsm)}条；资讯接口状态：{news_errors}")
            return 0

        print(f"开始盘后更新：观察池 {len(etfs)} 只ETF；更新时间 {asof}")
        start_date = (datetime.now() - timedelta(days=160)).strftime("%Y%m%d")
        end_date = datetime.now().strftime("%Y%m%d")
        hist_by_code: Dict[str, pd.DataFrame] = {}
        errors: Dict[str, str] = {}
        for i, e in enumerate(etfs, 1):
            try:
                print(f"[{i}/{len(etfs)}] 获取 {e['code']} {e['theme']} …")
                hist_by_code[e["code"]] = fetch_etf_hist(e["code"], start_date, end_date)
            except Exception as exc:
                errors[e["code"]] = str(exc)[:250]
            time.sleep(0.25)

        benchmark_code = config["benchmark"]
        benchmark_df = hist_by_code.get(benchmark_code)
        if benchmark_df is None and benchmark_code not in hist_by_code:
            try:
                benchmark_df = fetch_etf_hist(benchmark_code, start_date, end_date)
                hist_by_code[benchmark_code] = benchmark_df
            except Exception as exc:
                errors[benchmark_code] = str(exc)[:250]
        benchmark_metrics = None
        if benchmark_df is not None and not benchmark_df.empty:
            try: benchmark_metrics = series_metrics(benchmark_df, None)
            except Exception: benchmark_metrics = None

        growth_df = hist_by_code.get("588000")
        growth_metrics = None
        if growth_df is not None and not growth_df.empty:
            try: growth_metrics = series_metrics(growth_df, None)
            except Exception: growth_metrics = None
        trade_date = (benchmark_metrics or {}).get("trade_date") or max([df["date"].max().strftime("%Y-%m-%d") for df in hist_by_code.values() if not df.empty], default=datetime.now().strftime("%Y-%m-%d"))
        date_arg = trade_date.replace("-", "")
        pool_trade_date = trade_date
        pool_date_arg = date_arg

        up, down, breadth, breadth_status = fetch_breadth()
        zt_df, zt_status = fetch_pool("stock_zt_pool_em", pool_date_arg)
        bomb_df, bomb_status = fetch_pool("stock_zt_pool_zbgc_em", pool_date_arg)
        dt_df, dt_status = fetch_pool("stock_zt_pool_dtgc_em", pool_date_arg)
        # If latest trade date pool endpoints return empty, try previous calendar days (long holidays supported).
        if zt_df.empty:
            for back in range(1, 8):
                dt_try = (pd.to_datetime(trade_date) - timedelta(days=back)).strftime("%Y%m%d")
                zt2, _ = fetch_pool("stock_zt_pool_em", dt_try)
                if not zt2.empty:
                    pool_trade_date, pool_date_arg, zt_df = dt_try[:4]+"-"+dt_try[4:6]+"-"+dt_try[6:], dt_try, zt2
                    bomb_df, _ = fetch_pool("stock_zt_pool_zbgc_em", dt_try)
                    dt_df, _ = fetch_pool("stock_zt_pool_dtgc_em", dt_try)
                    zt_status = f"回退至最近有数据日期 {pool_trade_date}"
                    break
        limitups = int(len(zt_df)) if zt_df is not None and not zt_df.empty else 0
        broken = int(len(bomb_df)) if bomb_df is not None and not bomb_df.empty else 0
        limitdowns = int(len(dt_df)) if dt_df is not None and not dt_df.empty else 0
        max_streak = pool_streak_max(zt_df)
        broken_ratio = broken / (limitups + broken) if limitups + broken > 0 else None
        emotion_valid = not (zt_df.empty and bomb_df.empty and dt_df.empty)
        emotion = sentiment_score(breadth, limitups, limitdowns, broken, max_streak, emotion_valid)
        macro, market_score, macro_reason = compute_macro_score(breadth, emotion, benchmark_metrics, growth_metrics)
        state = market_state(market_score)
        equity = exposure_cap(market_score, config["max_equity"])

        news_rows, news_errors = fetch_news()
        news_available = len(news_rows) > 0
        lhb_df, lhb_status = fetch_lhb(date_arg)
        lhb_rows = normalize_lhb(lhb_df, trade_date, etfs)
        lhb_available = not lhb_df.empty

        scored = []
        for e in etfs:
            df = hist_by_code.get(e["code"])
            if df is None or df.empty:
                continue
            try:
                bm_ret = benchmark_metrics.get("ret20") if benchmark_metrics else None
                m = series_metrics(df, bm_ret)
                scored.append(score_etf(e, m, macro, emotion, news_rows, news_available, lhb_rows, lhb_available, market_score, config))
            except Exception as exc:
                errors[e["code"]] = f"计算指标失败：{exc}"

        recommended_total = allocate_weights(scored, config, market_score)
        # Exact history rows for latest 120 calendar days from each successfully fetched ETF.
        history_rows = []
        cutoff = pd.Timestamp.now().normalize() - pd.Timedelta(days=125)
        for e in etfs:
            df = hist_by_code.get(e["code"])
            if df is None or df.empty: continue
            recent = df[df["date"] >= cutoff].tail(100)
            for _, row in recent.iterrows():
                history_rows.append([
                    row["date"].strftime("%Y-%m-%d"), e["code"], e["theme"],
                    safe_float(row.get("open")), safe_float(row.get("close")), safe_float(row.get("high")), safe_float(row.get("low")),
                    safe_float(row.get("volume")), safe_float(row.get("amount")), safe_float(row.get("pct"))
                ])
        history_rows.sort(key=lambda x: (str(x[0]), str(x[1])))

        # Prepare standardized ladder data. Keep the raw theme/board description visible.
        ladder_rows: List[List[Any]] = []
        def append_pool(df: pd.DataFrame, pool_type: str):
            if df is None or df.empty: return
            for r in df.to_dict("records"):
                ladder_rows.append([
                    trade_date,
                    str(get_any(r, ["代码", "股票代码", "证券代码"], "") or ""),
                    str(get_any(r, ["名称", "股票简称"], "") or ""),
                    safe_float(get_any(r, ["涨跌幅", "涨跌幅%"])),
                    safe_float(get_any(r, ["最新价", "收盘价"])),
                    str(get_any(r, ["连板数", "连续涨停", "连板"], "" ) or ""),
                    str(get_any(r, ["所属行业", "行业"], "") or ""),
                    str(get_any(r, ["涨停统计", "涨停原因类别", "上榜原因"], "") or ""),
                    str(get_any(r, ["首次封板时间", "首次涨停时间"], "") or ""),
                    str(get_any(r, ["最后封板时间", "最后涨停时间"], "") or ""),
                    safe_float(get_any(r, ["封板资金", "封单资金"])),
                    safe_float(get_any(r, ["换手率", "换手率%"])),
                    pool_type
                ])
        # Pool dates can lag the ETF market date when the data source has not published its latest pool.
        trade_date_for_pools = pool_trade_date
        trade_date_for_rows = trade_date
        trade_date = trade_date_for_pools
        append_pool(zt_df, "涨停")
        append_pool(bomb_df, "炸板")
        append_pool(dt_df, "跌停")
        trade_date = trade_date_for_rows

        all_errors = []
        if errors: all_errors.append(f"ETF行情失败{len(errors)}只")
        if breadth_status != "OK": all_errors.append(breadth_status)
        if not news_available: all_errors.append("新闻源全部失败")
        if not lhb_available: all_errors.append(lhb_status)
        if zt_df.empty: all_errors.append(zt_status)
        data_status = "OK" if not all_errors else "部分数据缺失：" + "；".join(all_errors)[:400]
        market_info = {
            "trade_date": trade_date, "up": up, "down": down, "breadth": breadth, "limitup": limitups,
            "limitdown": limitdowns, "broken": broken, "broken_ratio": broken_ratio, "max_streak": max_streak,
            "benchmark_trend": ("收盘>MA20>MA60" if benchmark_metrics and benchmark_metrics["close"] > benchmark_metrics["ma20"] > benchmark_metrics["ma60"] else "偏强/盘整" if benchmark_metrics and benchmark_metrics["close"] > benchmark_metrics["ma60"] else "弱势/MA60下方" if benchmark_metrics else "缺失"),
            "growth_trend": ("收盘>MA20>MA60" if growth_metrics and growth_metrics["close"] > growth_metrics["ma20"] > growth_metrics["ma60"] else "偏强/盘整" if growth_metrics and growth_metrics["close"] > growth_metrics["ma60"] else "弱势/MA60下方" if growth_metrics else "缺失"),
            "emotion": emotion, "macro": macro, "market_score": round(market_score,1), "equity_cap": equity,
            "data_status": data_status, "macro_reason": macro_reason, "zt_status": zt_status, "bomb_status": bomb_status,
            "dt_status": dt_status, "breadth_status": breadth_status, "lhb_status": lhb_status, "news_errors": news_errors,
        }
        print("市场状态:", state, "| 市场分:", market_info["market_score"], "| 建议权益上限:", f"{equity:.0%}")
        print("数据状态:", data_status)
        # Update only after collection/calculation; preserve file if collection raises earlier.
        update_workbook(book, config, etfs, scored, market_info, ladder_rows, lhb_rows, news_rows, history_rows, asof)
        print(f"完成：{WORKBOOK}")
        print(f"成功计算ETF {len(scored)}/{len(etfs)}；ETF目标仓位合计 {recommended_total:.1%}，现金/低风险资产参考 {1-recommended_total:.1%}")
        print("说明：评分中政策/盈利分项使用新闻关键词代理；资金流动使用成交额活跃度代理，不代表真实ETF净申赎。")
        if errors:
            print("个别接口错误：")
            for code, err in errors.items(): print(" -", code, err)
        if news_errors:
            print("资讯接口状态：", news_errors)
        return 0
    except Exception as exc:
        print("更新失败：", exc)
        traceback.print_exc()
        return 1
    finally:
        try:
            if book is not None:
                book.Close(SaveChanges=True)
        except Exception:
            pass
        try:
            if excel is not None:
                excel.Quit()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
