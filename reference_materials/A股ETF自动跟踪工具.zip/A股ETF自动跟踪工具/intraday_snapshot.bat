@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Updating intraday ETF quotes only. Daily scores and target weights will not be recalculated.
python daily_update.py --intraday
if errorlevel 1 (
  echo Intraday update failed; check network/API status and Excel installation.
)
pause
