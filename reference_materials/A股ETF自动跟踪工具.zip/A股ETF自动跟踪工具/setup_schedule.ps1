# 在Windows PowerShell中运行此脚本，将创建4个工作日定时任务。
# Excel COM自动化需要当前用户保持登录，并且运行时不要手动打开目标工作簿。
$ErrorActionPreference = 'Stop'
$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonCmd = Get-Command python.exe -ErrorAction Stop
$python = $pythonCmd.Source
$script = Join-Path $folder 'daily_update.py'
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 40) -MultipleInstances IgnoreNew
$days = @('Monday','Tuesday','Wednesday','Thursday','Friday')
$tasks = @(
    @{ Name='A股ETF跟踪-盘前新闻'; Time='08:45'; Arg='--premarket'; Desc='抓取盘前公开财经资讯并按主题映射，不重算评分' },
    @{ Name='A股ETF跟踪-盘中上午快照'; Time='10:15'; Arg='--intraday'; Desc='更新盘中ETF行情快照，不重算日线评分' },
    @{ Name='A股ETF跟踪-盘中尾盘快照'; Time='14:30'; Arg='--intraday'; Desc='更新尾盘前ETF行情快照，不重算日线评分' },
    @{ Name='A股ETF跟踪-盘后评分'; Time='15:35'; Arg=''; Desc='更新ETF日线、市场情绪、涨停梯队、龙虎榜、新闻及目标仓位' }
)
foreach ($task in $tasks) {
    $trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $days -At ([datetime]::ParseExact($task.Time,'HH:mm',$null))
    $args = '"' + $script + '"'
    if ($task.Arg -ne '') { $args += ' ' + $task.Arg }
    $action = New-ScheduledTaskAction -Execute $python -Argument $args -WorkingDirectory $folder
    Register-ScheduledTask -TaskName $task.Name -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description $task.Desc -Force | Out-Null
    Write-Host "已创建任务：$($task.Name) @ $($task.Time)"
}
Write-Host ''
Write-Host '完成。请确认：当前用户保持登录；定时运行期间关闭Excel工作簿；中国法定节假日仍可能触发任务，但脚本按交易日数据更新。'
