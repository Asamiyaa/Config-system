@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Updating pre-market news only; scores/positions are not recalculated.
python daily_update.py --premarket
if errorlevel 1 echo Pre-market news update failed; check network/API status.
pause
