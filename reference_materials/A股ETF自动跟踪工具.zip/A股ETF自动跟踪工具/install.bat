@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Installing prerequisites: AKShare and pywin32...
python --version
python -m pip install --upgrade pip
python -m pip install --upgrade akshare pywin32 pandas
if errorlevel 1 (
  echo.
  echo Installation failed. Please install Python 3.11+ 64-bit and try again.
  pause
  exit /b 1
)
echo.
echo Installation complete. You can now run daily_update.bat
pause
