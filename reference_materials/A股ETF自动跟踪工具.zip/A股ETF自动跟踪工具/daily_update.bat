@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Running daily after-close refresh...
python daily_update.py
if errorlevel 1 (
  echo.
  echo Update failed. Read the error above; the last workbook snapshot is retained when possible.
)
pause
