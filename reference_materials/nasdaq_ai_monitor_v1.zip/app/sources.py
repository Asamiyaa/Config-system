from __future__ import annotations

import io
import json
import os
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any

import pandas as pd
import requests
from dotenv import load_dotenv

load_dotenv()


HEADERS = {
    "User-Agent": os.getenv("SEC_USER_AGENT", "NasdaqAI_Monitor/1.0 contact@example.com"),
    "Accept": "application/json,text/plain,*/*",
}


@dataclass
class Metric:
    value: float | None
    source: str
    quality: str = "official"
    note: str | None = None


class Http:
    def __init__(self, timeout: int = 25) -> None:
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": HEADERS["User-Agent"], "Accept": HEADERS["Accept"]})
        self.timeout = timeout

    def get_json(self, url: str, **kwargs: Any) -> Any:
        r = self.s.get(url, timeout=self.timeout, **kwargs)
        r.raise_for_status()
        return r.json()

    def get_text(self, url: str, **kwargs: Any) -> str:
        r = self.s.get(url, timeout=self.timeout, **kwargs)
        r.raise_for_status()
        return r.text


HTTP = Http()


def _clean_number(x: Any) -> float | None:
    if x in (None, "", "N/A", "-", "--"):
        return None
    if isinstance(x, (int, float)):
        return float(x)
    s = str(x).replace(",", "").replace("%", "").replace("$", "").strip()
    try:
        return float(s)
    except ValueError:
        return None


def _nasdaq_history_chunk(symbol: str, start: date, end: date) -> pd.DataFrame:
    url = f"https://api.nasdaq.com/api/quote/{symbol}/historical"
    params = {"assetclass": "index", "fromdate": start.isoformat(), "todate": end.isoformat(), "limit": 5000}
    headers = {**HEADERS, "Referer": f"https://www.nasdaq.com/market-activity/index/{symbol.lower()}/historical"}
    r = requests.get(url, params=params, headers=headers, timeout=25)
    r.raise_for_status()
    data = r.json()
    rows = (((data or {}).get("data") or {}).get("tradesTable") or {}).get("rows") or []
    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=["date", "close", "high", "low", "open"])
    if "date" not in df.columns:
        raise RuntimeError(f"Unexpected Nasdaq schema for {symbol}: {df.columns.tolist()}")
    df["date"] = pd.to_datetime(df["date"], errors="coerce").dt.date
    for col in ("close", "high", "low", "open"):
        if col in df.columns:
            df[col] = df[col].map(_clean_number)
    return df.dropna(subset=["date", "close"]).sort_values("date")


def nasdaq_history(symbol: str, days: int = 30) -> pd.DataFrame:
    end = date.today()
    start = end - timedelta(days=days)
    # 10-year chunks keep the Nasdaq endpoint below its row cap and allow
    # an all-history download for 2000-era similarity/drawdown calculations.
    chunks: list[pd.DataFrame] = []
    cur = start
    while cur <= end:
        chunk_end = min(cur + timedelta(days=3652), end)
        df = _nasdaq_history_chunk(symbol, cur, chunk_end)
        if not df.empty:
            chunks.append(df)
        cur = chunk_end + timedelta(days=1)
    if not chunks:
        raise RuntimeError(f"Nasdaq API returned no rows for {symbol}")
    out = pd.concat(chunks, ignore_index=True).drop_duplicates(subset=["date"]).sort_values("date")
    return out


def get_ndx_metrics(days: int = 365) -> tuple[pd.DataFrame, pd.DataFrame]:
    ndx = nasdaq_history("NDX", days)
    ndxe = nasdaq_history("NDXE", days)
    return ndx, ndxe


def cboe_vix(days: int = 3650) -> pd.DataFrame:
    url = "https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv"
    text = HTTP.get_text(url)
    df = pd.read_csv(io.StringIO(text))
    df.columns = [c.strip() for c in df.columns]
    date_col = next(c for c in df.columns if "date" in c.lower())
    close_col = next(c for c in df.columns if c.lower() in ("close", "vix close"))
    df["date"] = pd.to_datetime(df[date_col], errors="coerce").dt.date
    df["vix"] = pd.to_numeric(df[close_col], errors="coerce")
    return df[["date", "vix"]].dropna().tail(days)


def fred(series: list[str], days: int = 3650) -> pd.DataFrame:
    ids = ",".join(series)
    url = "https://fred.stlouisfed.org/graph/fredgraph.csv"
    text = HTTP.get_text(url, params={"id": ids})
    df = pd.read_csv(io.StringIO(text))
    df["DATE"] = pd.to_datetime(df["DATE"], errors="coerce").dt.date
    rename = {s: s for s in series}
    df = df.rename(columns=rename).tail(days)
    return df


def sec_companyfacts(cik: str) -> dict[str, Any]:
    url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"
    return HTTP.get_json(url)


def latest_fact(facts: dict[str, Any], tags: list[str], unit: str = "USD") -> dict[str, Any] | None:
    usgaap = facts.get("facts", {}).get("us-gaap", {})
    candidates: list[dict[str, Any]] = []
    for tag in tags:
        if tag not in usgaap:
            continue
        units = usgaap[tag].get("units", {})
        arr = units.get(unit) or units.get("USD/shares") or []
        for x in arr:
            if x.get("form") in {"10-Q", "10-K", "8-K"} and x.get("val") is not None:
                candidates.append({**x, "tag": tag})
    if not candidates:
        return None
    candidates.sort(key=lambda x: (x.get("filed") or "", x.get("end") or ""), reverse=True)
    return candidates[0]


def sec_fundamentals(cik: str) -> dict[str, Any]:
    facts = sec_companyfacts(cik)
    revenue = latest_fact(facts, ["RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues", "SalesRevenueNet"])
    cfo = latest_fact(facts, ["NetCashProvidedByUsedInOperatingActivities", "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations"])
    capex = latest_fact(facts, ["PaymentsToAcquirePropertyPlantAndEquipment"])
    op_income = latest_fact(facts, ["OperatingIncomeLoss"])
    assets = latest_fact(facts, ["Assets"])
    liabilities_current = latest_fact(facts, ["LiabilitiesCurrent"])
    cash = latest_fact(facts, ["CashAndCashEquivalentsAtCarryingValue", "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents"])
    debt = latest_fact(facts, ["LongTermDebtCurrent", "LongTermDebtNoncurrent", "LongTermDebtAndFinanceLeaseObligationsCurrent", "LongTermDebtAndFinanceLeaseObligationsNoncurrent"])
    return {
        "revenue": revenue,
        "cfo": cfo,
        "capex": capex,
        "op_income": op_income,
        "assets": assets,
        "liabilities_current": liabilities_current,
        "cash": cash,
        "debt": debt,
    }


def load_manual_inputs(path: str, asof: date | None = None) -> dict[str, Any]:
    df = pd.read_csv(path)
    if df.empty:
        return {}
    df["date"] = pd.to_datetime(df["date"], errors="coerce").dt.date
    asof = asof or date.today()
    df = df[df["date"] <= asof].sort_values("date")
    if df.empty:
        return {}
    row = df.iloc[-1].to_dict()
    return {k: row[k] for k in row if k != "date" and pd.notna(row[k])}


def ndx_constituents() -> list[str]:
    # Nasdaq exposes the current Nasdaq-100 constituent list through the
    # list-type endpoint. This endpoint is undocumented and may change, so
    # the caller treats failure as a non-fatal data-quality issue.
    url = "https://api.nasdaq.com/api/quote/list-type/nasdaq100"
    headers = {**HEADERS, "Referer": "https://www.nasdaq.com/market-activity/quotes/nasdaq-ndx-index"}
    r = requests.get(url, headers=headers, timeout=25)
    r.raise_for_status()
    data = r.json()
    rows = (((data or {}).get("data") or {}).get("data") or {}).get("rows") or []
    symbols = []
    for row in rows:
        sym = row.get("symbol") or row.get("Symbol")
        if sym:
            symbols.append(sym.replace(".", "-"))
    return symbols
