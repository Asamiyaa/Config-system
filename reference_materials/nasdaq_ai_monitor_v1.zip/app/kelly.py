from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class KellyStats:
    trigger: float
    n_events: int
    win_prob: float | None
    median_target_gain: float | None
    median_adverse: float | None
    payoff_ratio: float | None
    full_kelly: float | None
    quarter_kelly: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def kelly_fraction(p: float, b: float) -> float:
    q = 1.0 - p
    return (b * p - q) / b if b > 0 else 0.0


def drawdown_event_stats(prices: pd.Series, trigger: float, recovery_horizon_days: int = 756) -> KellyStats:
    s = pd.to_numeric(prices, errors="coerce").dropna().astype(float)
    if len(s) < 252:
        return KellyStats(trigger, 0, None, None, None, None, None, None)

    # Work with close-to-close drawdowns from running peaks. Each episode contributes
    # at most one event per trigger to avoid counting the same selloff repeatedly.
    events = []
    i = 1
    n = len(s)
    running_peak = s.iloc[0]
    while i < n:
        if s.iloc[i] > running_peak:
            running_peak = s.iloc[i]
            i += 1
            continue
        dd = s.iloc[i] / running_peak - 1.0
        if dd <= trigger:
            trigger_px = s.iloc[i]
            peak_px = running_peak
            end_i = min(n - 1, i + recovery_horizon_days)
            future = s.iloc[i:end_i + 1]
            recovery_idx = future[future >= peak_px].index
            success = len(recovery_idx) > 0
            target_gain = peak_px / trigger_px - 1.0
            adverse = max(0.0, 1.0 - float(future.min() / trigger_px))
            events.append({"success": success, "target_gain": target_gain, "adverse": adverse})

            # Move to the recovery point if recovered; otherwise move to the end of
            # the horizon. This makes events non-overlapping at a given trigger.
            if success:
                rec_pos = s.index.get_loc(recovery_idx[0])
                i = int(rec_pos) + 1
                running_peak = float(s.iloc[i - 1])
            else:
                i = end_i + 1
                running_peak = float(future.max())
            continue
        i += 1

    if not events:
        return KellyStats(trigger, 0, None, None, None, None, None, None)

    df = pd.DataFrame(events)
    p = float(df["success"].mean())
    target = float(df["target_gain"].median())
    adverse_values = df.loc[df["adverse"] > 0, "adverse"]
    adverse = float(adverse_values.median()) if not adverse_values.empty else 0.0
    b = target / adverse if adverse > 0 else None
    full = kelly_fraction(p, b) if b is not None else None
    full = max(0.0, min(1.0, full)) if full is not None else None
    quarter = full * 0.25 if full is not None else None
    return KellyStats(trigger, len(df), p, target, adverse, b, full, quarter)
