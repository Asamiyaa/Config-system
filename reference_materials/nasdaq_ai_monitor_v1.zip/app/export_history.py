from __future__ import annotations

import argparse
import json
from pathlib import Path

from .db import connect, load_history
from .report import write_csv


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--db', default='data/nasdaq_ai_monitor.sqlite3')
    p.add_argument('--limit', type=int, default=5000)
    p.add_argument('--out', default='data/daily_scores.csv')
    args = p.parse_args()
    conn = connect(args.db)
    rows = load_history(conn, args.limit)
    if not rows:
        print('No history')
        return
    import pandas as pd
    flat = []
    for row in rows:
        x = {'trade_date': row['trade_date']}
        x.update(row.get('metrics', {}))
        for k in ['bubble_score','bubble_coverage','similarity_2000','similarity_coverage','entry_score','entry_coverage','target_position','action']:
            x[k] = row.get(k)
        flat.append(x)
    pd.DataFrame(flat).sort_values('trade_date').to_csv(args.out, index=False, encoding='utf-8-sig')
    print(args.out)

if __name__ == '__main__':
    main()
