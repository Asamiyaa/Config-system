from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd


def flatten_for_csv(snapshot: dict[str, Any]) -> dict[str, Any]:
    row = {"trade_date": snapshot["trade_date"]}
    row.update(snapshot.get("metrics", {}))
    row.update({k: v for k, v in snapshot.items() if k not in {"trade_date", "metrics", "sources"}})
    return row


def write_csv(snapshot: dict[str, Any], path: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    row = flatten_for_csv(snapshot)
    if p.exists():
        df = pd.read_csv(p)
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
        df = df.drop_duplicates(subset=["trade_date"], keep="last").sort_values("trade_date")
    else:
        df = pd.DataFrame([row])
    df.to_csv(p, index=False, encoding="utf-8-sig")


def markdown(snapshot: dict[str, Any]) -> str:
    m = snapshot.get("metrics", {})
    lines = [
        f"# Nasdaq AI Bubble Monitor — {snapshot['trade_date']}",
        "",
        f"- AI泡沫分：**{snapshot.get('bubble_score')} / 100**（覆盖率 {snapshot.get('bubble_coverage')}%）",
        f"- 2000相似度：**{snapshot.get('similarity_2000')} / 100**（覆盖率 {snapshot.get('similarity_coverage')}%）",
        f"- 纳指配置分：**{snapshot.get('entry_score')} / 100**（覆盖率 {snapshot.get('entry_coverage')}%）",
        f"- 模型建议仓位：**{snapshot.get('target_position')}**",
        f"- 当前动作：**{snapshot.get('action')}**",
        "",
        "## 市场快照",
        "",
        "| 指标 | 值 |",
        "|---|---:|",
    ]
    for key in ["ndx_close", "drawdown", "ndxe_close", "vix", "DGS10", "NFCI", "HY_OAS", "BBB_OAS", "forward_pe", "eps_growth", "eps_revision_3m", "breadth_50", "breadth_200", "capex_cfo"]:
        lines.append(f"| {key} | {m.get(key)} |")
    lines += ["", "## 金字塔 + 1/4 Kelly 统计", "", "| 回撤触发 | 历史事件数 | 胜率 | 中位目标收益 | 中位后续不利幅度 | 盈亏比 b | 1/4 Kelly | 实际单次加仓上限 |", "|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for x in snapshot.get("kelly_plan", []):
        fmt = lambda v, pct=False: "-" if v is None else (f"{v:.1%}" if pct else f"{v:.2f}")
        lines.append(f"| {x['trigger']:.1%} | {x['n_events']} | {fmt(x['win_prob'], True)} | {fmt(x['median_target_gain'], True)} | {fmt(x['median_adverse'], True)} | {fmt(x['payoff_ratio'])} | {fmt(x['quarter_kelly'], True)} | {fmt(x['effective_allocation'], True)} |")
    lines += ["", "## 数据质量", "", snapshot.get("data_quality", "UNKNOWN"), ""]
    return "\n".join(lines)


def write_report(snapshot: dict[str, Any], path: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(markdown(snapshot), encoding="utf-8")
