from __future__ import annotations

from dataclasses import dataclass
from math import exp
from typing import Iterable

import numpy as np
import pandas as pd


@dataclass
class ScoreResult:
    score: float
    coverage: float
    details: dict[str, float]


def clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, float(x)))


def percentile_rank(history: pd.Series, value: float) -> float | None:
    s = pd.to_numeric(history, errors="coerce").dropna()
    if len(s) < 20 or value is None or not np.isfinite(value):
        return None
    return float((s <= value).mean() * 100.0)


def sigmoid_score(x: float, midpoint: float, scale: float) -> float:
    z = (x - midpoint) / max(scale, 1e-9)
    return 100.0 / (1.0 + exp(-z))


def weighted_score(parts: dict[str, float | None], weights: dict[str, float]) -> ScoreResult:
    vals = {k: v for k, v in parts.items() if v is not None and np.isfinite(v)}
    w = {k: weights[k] for k in vals if k in weights}
    denom = sum(w.values())
    if denom <= 0:
        return ScoreResult(np.nan, 0.0, {})
    score = sum(vals[k] * w[k] for k in w) / denom
    coverage = denom / sum(weights.values()) * 100.0
    return ScoreResult(clamp(score), coverage, vals)


def bubble_score(metrics: dict[str, float | None], weights: dict[str, float]) -> ScoreResult:
    """Risk score: higher = more bubble/systemic risk."""
    parts: dict[str, float | None] = {}

    # Already standardized/manual or computed inputs.
    parts["valuation"] = metrics.get("valuation_risk")
    parts["earnings"] = metrics.get("earnings_risk")

    # CapEx risk: combines CapEx growth minus revenue growth, and CapEx/CFO.
    capex_gap = metrics.get("capex_growth_minus_revenue_growth")
    capex_cfo = metrics.get("capex_cfo")
    capex1 = sigmoid_score(capex_gap, midpoint=20, scale=15) if capex_gap is not None else None
    capex2 = sigmoid_score(capex_cfo, midpoint=1.0, scale=0.35) if capex_cfo is not None else None
    parts["capex"] = np.nanmean([x for x in [capex1, capex2] if x is not None]) if any(x is not None for x in [capex1, capex2]) else None

    parts["fcf_roic"] = metrics.get("fcf_roic_risk")
    parts["ai_monetization"] = metrics.get("ai_monetization_risk")
    parts["financing"] = metrics.get("ai_financing_risk")
    parts["rates_liquidity"] = metrics.get("rates_liquidity_risk")
    parts["breadth_concentration"] = metrics.get("breadth_concentration_risk")
    parts["credit_volatility"] = metrics.get("credit_volatility_risk")
    return weighted_score(parts, weights)


def similarity_2000(metrics: dict[str, float | None], weights: dict[str, float]) -> ScoreResult:
    """Similarity to the structural features of the dot-com bust, 0-100."""
    parts = {
        "valuation_extreme": metrics.get("valuation_2000_similarity"),
        "profitability": metrics.get("profitability_2000_similarity"),
        "capex_debt": metrics.get("capex_debt_2000_similarity"),
        "financing": metrics.get("financing_2000_similarity"),
        "concentration": metrics.get("concentration_2000_similarity"),
        "breadth": metrics.get("breadth_2000_similarity"),
    }
    return weighted_score(parts, weights)


def entry_score(metrics: dict[str, float | None], weights: dict[str, float]) -> ScoreResult:
    """Higher = better current entry opportunity."""
    parts = {
        "valuation": metrics.get("valuation_entry"),
        "drawdown": metrics.get("drawdown_entry"),
        "earnings": metrics.get("earnings_entry"),
        "macro": metrics.get("macro_entry"),
        "breadth": metrics.get("breadth_entry"),
    }
    return weighted_score(parts, weights)


def target_position(entry_score_value: float | None, bubble_score_value: float | None) -> float:
    """Behavioral rule, intentionally conservative; backtest before using with real money."""
    if entry_score_value is None or bubble_score_value is None:
        return np.nan
    e = clamp(entry_score_value)
    b = clamp(bubble_score_value)
    # Base 25% + opportunity premium - bubble penalty.
    target = 0.25 + 0.75 * (e / 100.0) - 0.45 * (b / 100.0)
    return float(max(0.10, min(1.00, target)))


def pyramid_trigger(drawdown: float | None, levels: Iterable[dict]) -> str:
    if drawdown is None:
        return "UNKNOWN"
    triggered = [x for x in levels if drawdown <= x["drawdown"]]
    if not triggered:
        return "NONE"
    deepest = sorted(triggered, key=lambda x: x["drawdown"])[-1]
    return f"ADD_{abs(deepest['allocation']):.1%}"
