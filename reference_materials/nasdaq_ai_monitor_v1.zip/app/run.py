from __future__ import annotations

import argparse
import os
from datetime import date
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

from .db import connect, save_snapshot
from .engine import build_metrics, compute_report, breadth_from_prices
from .report import write_csv, write_report
from .sources import cboe_vix, fred, get_ndx_metrics, load_manual_inputs, ndx_constituents, sec_fundamentals


def load_config(path: str) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def aggregate_company_fundamentals(config: dict[str, Any]) -> dict[str, float | None]:
    rows = []
    for ticker, cik in config["companies"].items():
        try:
            facts = sec_fundamentals(cik)
        except Exception as e:
            print(f"SEC {ticker} failed: {e}")
            continue
        def val(name: str) -> float | None:
            item = facts.get(name)
            return float(item["val"]) if item and item.get("val") is not None else None
        rows.append({"ticker": ticker, "revenue": val("revenue"), "cfo": val("cfo"), "capex": val("capex"), "op_income": val("op_income"), "assets": val("assets"), "liabilities_current": val("liabilities_current"), "cash": val("cash"), "debt": val("debt")})
    if not rows:
        return {"capex_cfo": None, "capex_growth_minus_revenue_growth": None, "fcf_roic_risk": None}
    df = pd.DataFrame(rows)
    # Latest reported values are not always same fiscal period; keep this as a transparent cross-company snapshot.
    sum_capex = pd.to_numeric(df["capex"], errors="coerce").abs().sum(min_count=1)
    sum_cfo = pd.to_numeric(df["cfo"], errors="coerce").sum(min_count=1)
    capex_cfo = float(sum_capex / sum_cfo) if pd.notna(sum_capex) and pd.notna(sum_cfo) and sum_cfo != 0 else None
    # Without period-aligned quarterly histories, do not invent a growth rate.
    fcf_roic_risk = None
    if capex_cfo is not None:
        fcf_roic_risk = float(np.clip((capex_cfo - 0.45) / 1.55 * 100, 0, 100))
    return {"capex_cfo": capex_cfo, "capex_growth_minus_revenue_growth": None, "fcf_roic_risk": fcf_roic_risk}


def get_breadth(enable: bool) -> dict[str, float | None]:
    if not enable:
        return {"breadth_50": None, "breadth_200": None}
    try:
        import yfinance as yf
        symbols = ndx_constituents()
        if not symbols:
            return {"breadth_50": None, "breadth_200": None}
        data = yf.download(symbols, period="1y", interval="1d", auto_adjust=True, progress=False, threads=True, group_by="column")
        if isinstance(data.columns, pd.MultiIndex) and "Close" in data.columns.get_level_values(0):
            prices = data["Close"]
        elif "Close" in data.columns:
            prices = data[["Close"]]
        else:
            return {"breadth_50": None, "breadth_200": None}
        return breadth_from_prices(prices)
    except Exception as e:
        print(f"Breadth failed: {e}")
        return {"breadth_50": None, "breadth_200": None}


def main() -> None:
    parser = argparse.ArgumentParser(description="NASDAQ AI Bubble Monitor")
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--asof", default=None, help="YYYY-MM-DD, for replay/testing")
    parser.add_argument("--breadth", action="store_true", help="Download NDX constituents and compute % above 50/200DMA")
    parser.add_argument("--skip-sec", action="store_true", help="Skip SEC company facts")
    args = parser.parse_args()

    config = load_config(args.config)
    asof = date.fromisoformat(args.asof) if args.asof else date.today()
    ndx, ndxe = get_ndx_metrics(days=config["scoring"]["history_window_days"])
    vix = cboe_vix(days=config["scoring"]["history_window_days"])
    fred_df = fred(["DGS10", "NFCI", "BAMLH0A0HYM2", "BAMLC0A4CBBB"], days=config["scoring"]["history_window_days"])
    manual = load_manual_inputs("data/manual_inputs.csv", asof=asof)
    breadth = get_breadth(args.breadth)
    company = aggregate_company_fundamentals(config) if not args.skip_sec else {"capex_cfo": None, "capex_growth_minus_revenue_growth": None, "fcf_roic_risk": None}

    ndx = ndx[ndx["date"] <= asof]
    ndxe = ndxe[ndxe["date"] <= asof]
    vix = vix[vix["date"] <= asof]
    fred_df = fred_df[fred_df["DATE"] <= asof]
    metrics, _ = build_metrics(ndx, ndxe, fred_df, vix, manual, breadth, company)
    report = compute_report(config, metrics, ndx_history=pd.Series(ndx["close"].values, index=pd.to_datetime(ndx["date"])))

    non_null = sum(v is not None for v in metrics.values())
    total_core = 20
    quality = f"Core metric non-null count: {non_null}/{total_core}. Missing premium/qualitative inputs remain explicit; do not treat a partial score as production-ready."

    snapshot = {"trade_date": str(asof), "metrics": metrics, **report, "data_quality": quality,
                "sources": {"NDX": "Nasdaq", "NDXE": "Nasdaq", "VIX": "Cboe", "macro": "FRED", "fundamentals": "SEC XBRL", "breadth": "Nasdaq constituents + yfinance prices", "manual": "data/manual_inputs.csv"}}

    conn = connect(config["project"]["database"])
    save_snapshot(conn, str(asof), snapshot)
    write_csv(snapshot, config["project"]["csv_output"])
    write_report(snapshot, config["project"]["report_output"])

    print(f"Trade date: {asof}")
    print(f"AI bubble score: {snapshot['bubble_score']} / 100 (coverage {snapshot['bubble_coverage']}%)")
    print(f"2000 similarity: {snapshot['similarity_2000']} / 100 (coverage {snapshot['similarity_coverage']}%)")
    print(f"Entry score: {snapshot['entry_score']} / 100 (coverage {snapshot['entry_coverage']}%)")
    print(f"Target position: {snapshot['target_position']}")
    print(f"Action: {snapshot['action']}")
    print(f"Saved: {config['project']['database']}, {config['project']['csv_output']}, {config['project']['report_output']}")


if __name__ == "__main__":
    main()
