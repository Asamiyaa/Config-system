from __future__ import annotations

from datetime import date
from typing import Any

import numpy as np
import pandas as pd
import yaml

from .scoring import bubble_score, entry_score, similarity_2000, target_position
from .kelly import drawdown_event_stats


def latest_value(df: pd.DataFrame, col: str) -> float | None:
    if col not in df.columns:
        return None
    s = pd.to_numeric(df[col], errors="coerce").dropna()
    return float(s.iloc[-1]) if not s.empty else None


def calculate_drawdown(prices: pd.Series) -> tuple[float | None, float | None]:
    s = pd.to_numeric(prices, errors="coerce").dropna()
    if s.empty:
        return None, None
    peak = float(s.cummax().iloc[-1])
    dd = float(s.iloc[-1] / peak - 1.0)
    return dd, peak


def breadth_from_prices(price_df: pd.DataFrame) -> dict[str, float | None]:
    """price_df columns are tickers, rows are dates; values are adjusted close."""
    if price_df.empty:
        return {"breadth_50": None, "breadth_200": None}
    out: dict[str, float | None] = {}
    for window, key in [(50, "breadth_50"), (200, "breadth_200")]:
        if len(price_df) < window:
            out[key] = None
            continue
        ma = price_df.rolling(window).mean().iloc[-1]
        last = price_df.iloc[-1]
        valid = last.notna() & ma.notna()
        out[key] = float((last[valid] > ma[valid]).mean() * 100.0) if valid.any() else None
    return out


def build_metrics(ndx: pd.DataFrame, ndxe: pd.DataFrame, fred_df: pd.DataFrame, vix_df: pd.DataFrame,
                  manual: dict[str, Any], breadth: dict[str, float | None], company_agg: dict[str, float | None]) -> tuple[dict[str, float | None], dict[str, Any]]:
    merged = ndx[["date", "close"]].merge(ndxe[["date", "close"]], on="date", how="outer", suffixes=("_ndx", "_ndxe")).sort_values("date")
    ndx_close = pd.to_numeric(merged["close_ndx"], errors="coerce").dropna()
    dd, peak = calculate_drawdown(ndx_close)

    vix = vix_df.copy()
    vix_latest = latest_value(vix, "vix")
    dgs10 = latest_value(fred_df, "DGS10")
    nfci = latest_value(fred_df, "NFCI")
    hy = latest_value(fred_df, "BAMLH0A0HYM2")
    bbb = latest_value(fred_df, "BAMLC0A4CBBB")

    forward_pe = float(manual["forward_pe"]) if manual.get("forward_pe") is not None else None
    eps_growth = float(manual["eps_growth"]) if manual.get("eps_growth") is not None else None
    eps_revision = float(manual["eps_revision_3m"]) if manual.get("eps_revision_3m") is not None else None
    ai_monetization = float(manual["ai_monetization_risk"]) if manual.get("ai_monetization_risk") is not None else None
    ai_financing = float(manual["ai_financing_risk"]) if manual.get("ai_financing_risk") is not None else None
    concentration = float(manual["concentration_risk"]) if manual.get("concentration_risk") is not None else None

    # Manual/relative scores. These are intentionally transparent so you can later replace them
    # with a paid/official adapter without touching the scoring layer.
    valuation_risk = None if forward_pe is None else float(np.clip((forward_pe - 17.0) / (28.0 - 17.0) * 100.0, 0, 100))
    earnings_risk = None if eps_growth is None else float(np.clip(65.0 - eps_growth, 0, 100))
    earnings_entry = None if eps_growth is None else float(np.clip(50.0 + eps_growth, 0, 100))
    valuation_entry = None if valuation_risk is None else 100.0 - valuation_risk

    capex_cfo = company_agg.get("capex_cfo")
    capex_growth_minus_revenue_growth = company_agg.get("capex_growth_minus_revenue_growth")
    fcf_roic_risk = company_agg.get("fcf_roic_risk")

    rates_risk = None
    if dgs10 is not None or nfci is not None:
        r1 = np.clip((dgs10 - 2.5) / (6.0 - 2.5) * 100, 0, 100) if dgs10 is not None else np.nan
        r2 = np.clip((nfci + 1.0) / 2.0 * 100, 0, 100) if nfci is not None else np.nan
        rates_risk = float(np.nanmean([r1, r2]))

    breadth_50 = breadth.get("breadth_50")
    breadth_200 = breadth.get("breadth_200")
    breadth_risk = None
    breadth_entry = None
    if breadth_50 is not None or breadth_200 is not None:
        vals = [x for x in [breadth_50, breadth_200] if x is not None]
        breadth_entry = float(np.mean(vals))
        breadth_risk = 100.0 - breadth_entry

    credit_risk = None
    if hy is not None or bbb is not None or vix_latest is not None:
        c1 = np.clip((hy - 2.0) / (10.0 - 2.0) * 100, 0, 100) if hy is not None else np.nan
        c2 = np.clip((bbb - 0.5) / (5.0 - 0.5) * 100, 0, 100) if bbb is not None else np.nan
        c3 = np.clip((vix_latest - 12.0) / (40.0 - 12.0) * 100, 0, 100) if vix_latest is not None else np.nan
        credit_risk = float(np.nanmean([c1, c2, c3]))

    drawdown_entry = None if dd is None else float(np.clip((-dd) * 400 + 20, 0, 100))
    macro_entry = None if rates_risk is None else 100.0 - rates_risk

    similarity_inputs = {
        "valuation_2000_similarity": valuation_risk * 0.45 if valuation_risk is not None else None,
        "profitability_2000_similarity": earnings_risk * 0.25 if earnings_risk is not None else None,
        "capex_debt_2000_similarity": None if capex_cfo is None else np.clip((capex_cfo - 0.5) / 1.5 * 100, 0, 100),
        "financing_2000_similarity": ai_financing,
        "concentration_2000_similarity": concentration,
        "breadth_2000_similarity": breadth_risk,
    }

    metrics = {
        "ndx_close": float(ndx_close.iloc[-1]) if not ndx_close.empty else None,
        "ndx_peak": peak,
        "drawdown": dd,
        "ndxe_close": latest_value(ndxe, "close"),
        "vix": vix_latest,
        "DGS10": dgs10,
        "NFCI": nfci,
        "HY_OAS": hy,
        "BBB_OAS": bbb,
        "forward_pe": forward_pe,
        "eps_growth": eps_growth,
        "eps_revision_3m": eps_revision,
        "breadth_50": breadth_50,
        "breadth_200": breadth_200,
        "capex_cfo": capex_cfo,
        "capex_growth_minus_revenue_growth": capex_growth_minus_revenue_growth,
        "fcf_roic_risk": fcf_roic_risk,
        "valuation_risk": valuation_risk,
        "earnings_risk": earnings_risk,
        "ai_monetization_risk": ai_monetization,
        "ai_financing_risk": ai_financing,
        "rates_liquidity_risk": rates_risk,
        "breadth_concentration_risk": breadth_risk if concentration is None else float(np.nanmean([breadth_risk, concentration])) if breadth_risk is not None else concentration,
        "credit_volatility_risk": credit_risk,
        "valuation_entry": valuation_entry,
        "drawdown_entry": drawdown_entry,
        "earnings_entry": earnings_entry,
        "macro_entry": macro_entry,
        "breadth_entry": breadth_entry,
        **similarity_inputs,
    }
    return metrics, {"peak": peak, "drawdown": dd}


def compute_report(config: dict[str, Any], metrics: dict[str, float | None], ndx_history: pd.Series | None = None) -> dict[str, Any]:
    bubble = bubble_score(metrics, config["scoring"]["bubble_weights"])
    sim = similarity_2000(metrics, config["scoring"]["similarity_weights"])
    entry = entry_score(metrics, config["scoring"]["entry_weights"])
    position = target_position(entry.score if np.isfinite(entry.score) else None, bubble.score if np.isfinite(bubble.score) else None)

    kelly_plan = []
    if ndx_history is not None and not ndx_history.empty:
        for level in config["strategy"]["pyramid"]:
            stats = drawdown_event_stats(ndx_history, float(level["drawdown"]))
            planned = float(level["allocation"])
            kelly_cap = stats.quarter_kelly if stats.quarter_kelly is not None else None
            effective = min(planned, kelly_cap) if kelly_cap is not None else planned
            kelly_plan.append({**stats.to_dict(), "planned_allocation": planned, "effective_allocation": effective})

    dd = metrics.get("drawdown")
    if dd is None:
        action = "DATA_INCOMPLETE"
    elif dd <= config["strategy"]["bear_market_drawdown"] and bubble.score >= 70:
        action = "BEAR_MARKET_CONFIRMATION_MODE"
    elif bubble.score >= 70:
        action = "DEFENSIVE"
    elif entry.score >= 70:
        action = "ADD_ON_WEAKNESS"
    elif dd <= -0.05:
        action = "PYRAMID_ADD"
    else:
        action = "BASE_PLUS_DCA"

    return {
        "bubble_score": round(bubble.score, 2) if np.isfinite(bubble.score) else None,
        "bubble_coverage": round(bubble.coverage, 1),
        "bubble_details": bubble.details,
        "similarity_2000": round(sim.score, 2) if np.isfinite(sim.score) else None,
        "similarity_coverage": round(sim.coverage, 1),
        "similarity_details": sim.details,
        "entry_score": round(entry.score, 2) if np.isfinite(entry.score) else None,
        "entry_coverage": round(entry.coverage, 1),
        "entry_details": entry.details,
        "target_position": round(position, 4) if np.isfinite(position) else None,
        "kelly_plan": kelly_plan,
        "action": action,
    }
