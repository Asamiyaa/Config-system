from __future__ import annotations

import argparse

import pandas as pd

from .db import connect


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--db", default="data/nasdaq_ai_monitor.sqlite3")
    p.add_argument("--n", type=int, default=30)
    args = p.parse_args()
    conn = connect(args.db)
    df = pd.read_sql_query(
        "SELECT trade_date, payload_json FROM daily_scores ORDER BY trade_date DESC LIMIT ?", conn, params=[args.n]
    )
    if df.empty:
        print("No history yet.")
        return
    rows = []
    import json
    for _, r in df.iterrows():
        pld = json.loads(r.payload_json)
        rows.append({
            "date": r.trade_date,
            "AI泡沫分": pld.get("bubble_score"),
            "2000相似度": pld.get("similarity_2000"),
            "纳指配置分": pld.get("entry_score"),
            "建议仓位": pld.get("target_position"),
            "动作": pld.get("action"),
        })
    print(pd.DataFrame(rows).to_string(index=False))

if __name__ == "__main__":
    main()
