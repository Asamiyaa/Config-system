from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any


SCHEMA = """
CREATE TABLE IF NOT EXISTS daily_scores (
    trade_date TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS metric_history (
    trade_date TEXT NOT NULL,
    metric TEXT NOT NULL,
    value REAL,
    source TEXT,
    quality TEXT,
    PRIMARY KEY (trade_date, metric)
);
"""


def connect(db_path: str | Path) -> sqlite3.Connection:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(SCHEMA)
    return conn


def save_snapshot(conn: sqlite3.Connection, trade_date: str, payload: dict[str, Any]) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO daily_scores(trade_date, payload_json) VALUES (?, ?)",
        (trade_date, json.dumps(payload, ensure_ascii=False, default=str)),
    )
    metrics = payload.get("metrics", {})
    for metric, item in metrics.items():
        if isinstance(item, dict):
            value = item.get("value")
            source = item.get("source")
            quality = item.get("quality")
        else:
            value, source, quality = item, None, None
        conn.execute(
            "INSERT OR REPLACE INTO metric_history(trade_date, metric, value, source, quality) VALUES (?, ?, ?, ?, ?)",
            (trade_date, metric, value, source, quality),
        )
    conn.commit()


def load_history(conn: sqlite3.Connection, limit: int = 1000) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT trade_date, payload_json FROM daily_scores ORDER BY trade_date DESC LIMIT ?", (limit,)
    ).fetchall()
    return [{"trade_date": r[0], **json.loads(r[1])} for r in rows]
