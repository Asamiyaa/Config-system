# Nasdaq AI Bubble Monitor v1.0

一个面向长期纳斯达克100投资的每日量化监控器，输出四个核心结果：

1. **AI泡沫分**：0-100，越高越危险。
2. **2000相似度**：0-100，越高越接近互联网泡沫式结构。
3. **纳指配置分**：0-100，越高越适合增加风险暴露。
4. **建议仓位**：0-100%，用于把评分转换为一个明确的仓位参考。

同时每日把原始指标和评分写入 SQLite + CSV，形成长期时间序列表。

## 数据分层

### 自动获取（免费官方/准官方）
- Nasdaq：NDX、NDXE、当前 Nasdaq-100 成分股列表（list-type endpoint）
- Cboe：VIX历史数据
- FRED：DGS10、NFCI、HY OAS、BBB OAS
- SEC XBRL：MSFT/AMZN/GOOGL/META/ORCL/NVDA 的最新财务事实
- yfinance：成分股历史价格，用于计算 %Above50DMA / %Above200DMA

### 需要你维护或以后接入付费数据
- NDX Forward P/E
- EPS 预期与3个月修正
- AI终端变现风险
- AI融资风险
- 集中度风险

这些字段放在 `data/manual_inputs.csv`，不能让程序猜测。

## 安装

```bash
python -m venv .venv
# Windows PowerShell
.venv\\Scripts\\Activate.ps1
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env   # Windows
# cp .env.example .env    # macOS/Linux
```

建议至少设置：

```text
SEC_USER_AGENT=YourName/1.0 your-email@example.com
```

SEC 官方 Companyfacts API 对单家公司可以一次返回全部 company concepts，详见：
https://www.sec.gov/search-filings/edgar-application-programming-interfaces

## 每日运行

最小版（不跑宽度、不拉SEC）：

```bash
python -m app.run --skip-sec
```

生产版：

```bash
python -m app.run --breadth
```

输出：

```text
data/nasdaq_ai_monitor.sqlite3
 data/daily_scores.csv
 data/latest_report.md
```

## 为什么保留“覆盖率”

如果Forward P/E、EPS revision、AI monetization等字段缺失，程序不会假装有答案，而会：

- 只使用可用指标重新归一化权重；
- 输出 `coverage`；
- 在报告标注数据质量；
- coverage低于配置阈值时，不应把仓位建议直接用于真实交易。

## 当前策略层

基础策略是此前讨论的 **25/25/50**：

- 25%：先建底仓
- 25%：8周时间定投
- 50%：按 -5/-8/-12/-16/-20% 回撤做金字塔
- -20%以后不再机械马丁，切换熊市确认模式
- 每个回撤档位从历史NDX回撤事件估计 p、b，并用 **1/4 Kelly** 作为单次加仓上限；没有足够历史样本时保留计划仓位，但标记为低置信度。

评分系统只是“风险预算器”，不能预测下一天涨跌。

## Windows 定时

建议用“任务计划程序”每天运行，例如美股收盘后北京时间早上运行：

```text
Program: C:\\path\\to\\python.exe
Arguments: -m app.run --breadth
Start in: C:\\path\\to\\nasdaq_ai_monitor
```

## 重要：第一版需要回测

当前仓位映射函数是一个**明确、可解释的初始规则**，不是经过历史优化后的最优解。真正用于实盘之前，应至少做：

- 2000、2008、2020、2022、2025-2026 等阶段回测
- 参数敏感性：-5/-8/-12/-16/-20是否优于其他分层
- Kelly 1/4、1/3、1/2 的稳定性
- 最大回撤、年化收益、Sortino、Calmar
- 现金机会成本
- 国内QDII ETF折溢价造成的执行偏差


`.env` 会由程序自动加载；SEC_USER_AGENT 建议使用真实联系邮箱。
