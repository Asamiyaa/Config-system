from app.scoring import bubble_score, entry_score, similarity_2000, target_position


def test_weighted_scores_and_position():
    metrics = {
        "valuation_risk": 20,
        "earnings_risk": 10,
        "capex_growth_minus_revenue_growth": 35,
        "capex_cfo": 0.9,
        "fcf_roic_risk": 40,
        "ai_monetization_risk": 50,
        "ai_financing_risk": 60,
        "rates_liquidity_risk": 50,
        "breadth_concentration_risk": 60,
        "credit_volatility_risk": 20,
        "valuation_entry": 80,
        "drawdown_entry": 40,
        "earnings_entry": 90,
        "macro_entry": 50,
        "breadth_entry": 40,
        "valuation_2000_similarity": 15,
        "profitability_2000_similarity": 10,
        "capex_debt_2000_similarity": 40,
        "financing_2000_similarity": 50,
        "concentration_2000_similarity": 70,
        "breadth_2000_similarity": 60,
    }
    b = bubble_score(metrics, {"valuation":15,"earnings":15,"capex":15,"fcf_roic":15,"ai_monetization":10,"financing":10,"rates_liquidity":10,"breadth_concentration":5,"credit_volatility":5})
    e = entry_score(metrics, {"valuation":30,"drawdown":25,"earnings":20,"macro":15,"breadth":10})
    s = similarity_2000(metrics, {"valuation_extreme":20,"profitability":20,"capex_debt":20,"financing":15,"concentration":15,"breadth":10})
    assert 0 <= b.score <= 100
    assert 0 <= e.score <= 100
    assert 0 <= s.score <= 100
    p = target_position(e.score, b.score)
    assert 0.10 <= p <= 1.00
